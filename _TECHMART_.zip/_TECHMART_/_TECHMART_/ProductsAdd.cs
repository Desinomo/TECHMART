﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ProductsAdd : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        private IMongoCollection<BsonDocument> brandsCollection;
        private IMongoCollection<BsonDocument> categoriesCollection;
        private IMongoCollection<BsonDocument> productsCollection;
        public event Action DataUpdated;

        public ProductsAdd()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadBrands();
            LoadCategories();
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");

                brandsCollection = database.GetCollection<BsonDocument>("brands");
                categoriesCollection = database.GetCollection<BsonDocument>("Сategories");
                productsCollection = database.GetCollection<BsonDocument>("products");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private async void LoadBrands()
        {
            var brands = await brandsCollection.Find(new BsonDocument()).ToListAsync();

            DataTable brandTable = new DataTable();
            brandTable.Columns.Add("brand_id", typeof(string));
            brandTable.Columns.Add("name", typeof(string));

            foreach (var brand in brands)
            {
                var brandId = brand["_id"].AsObjectId; 
                var brandName = brand["name"].ToString();
                brandTable.Rows.Add(brandId, brandName);
            }

            cb.DataSource = brandTable;
            cb.DisplayMember = "name";
            cb.ValueMember = "brand_id";
        }

        private async void LoadCategories()
        {
            try
            {
                var categoriesCollection = database.GetCollection<BsonDocument>("Categories");

                var categories = await categoriesCollection.Find(new BsonDocument()).ToListAsync();

                if (categories.Count == 0)
                {
                    MessageBox.Show("Немає доступних категорій.");
                    return;
                }
                DataTable categoryTable = new DataTable();
                categoryTable.Columns.Add("category_id", typeof(string));
                categoryTable.Columns.Add("name", typeof(string));

                foreach (var category in categories)
                {
                    var categoryId = category["_id"].AsObjectId; 
                    var categoryName = category["name"].ToString(); 
                    categoryTable.Rows.Add(categoryId, categoryName);
                }

                ck.DataSource = categoryTable;
                ck.DisplayMember = "name"; 
                ck.ValueMember = "category_id";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка завантаження категорій: " + ex.Message);
            }
        }



        private async void ba_Click(object sender, EventArgs e)
        {
            try
            {
                var productName = txn.Text;
                var brandId = cb.SelectedValue?.ToString();
                var categoryId = ck.SelectedValue?.ToString(); 
                var price = Convert.ToInt32(txc.Text);
                var quantity = Convert.ToInt32(txk.Text);

                if (string.IsNullOrEmpty(productName) || string.IsNullOrEmpty(brandId) || string.IsNullOrEmpty(categoryId))
                {
                    MessageBox.Show("Будь ласка, заповніть всі поля.");
                    return;
                }

                var newProduct = new BsonDocument
                {
                    { "name", productName },
                    { "brand_id", brandId },
                    { "category_id", categoryId },
                    { "price", price },
                    { "quantity", quantity }
                };

                await productsCollection.InsertOneAsync(newProduct);
                DataUpdated?.Invoke();
                MessageBox.Show("Продукт успішно додано!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при додаванні продукту: " + ex.Message);
            }
        }
    }
}
