﻿namespace _TECHMART_
{
    partial class Mainmenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            btob = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Azure;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button1.Location = new Point(12, 66);
            button1.Name = "button1";
            button1.Size = new Size(179, 92);
            button1.TabIndex = 0;
            button1.Text = "Клієнти";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Constantia", 24F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(66, 9);
            label1.Name = "label1";
            label1.Size = new Size(265, 39);
            label1.TabIndex = 1;
            label1.Text = "Оберіть функцію";
            // 
            // button2
            // 
            button2.BackColor = Color.Azure;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button2.Location = new Point(207, 66);
            button2.Name = "button2";
            button2.Size = new Size(181, 92);
            button2.TabIndex = 2;
            button2.Text = "Замовлення";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Azure;
            button3.Cursor = Cursors.Hand;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button3.Location = new Point(207, 164);
            button3.Name = "button3";
            button3.Size = new Size(181, 92);
            button3.TabIndex = 3;
            button3.Text = "Електроніка";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Azure;
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button4.Location = new Point(12, 164);
            button4.Name = "button4";
            button4.Size = new Size(179, 92);
            button4.TabIndex = 4;
            button4.Text = "Звіти";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // btob
            // 
            btob.BackColor = Color.Azure;
            btob.Cursor = Cursors.Hand;
            btob.FlatAppearance.BorderColor = Color.FromArgb(64, 0, 0);
            btob.FlatStyle = FlatStyle.Popup;
            btob.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btob.Location = new Point(12, 262);
            btob.Name = "btob";
            btob.Size = new Size(376, 92);
            btob.TabIndex = 6;
            btob.Text = "Бренди та категорії";
            btob.UseVisualStyleBackColor = false;
            btob.Click += btob_Click;
            // 
            // Mainmenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(400, 377);
            Controls.Add(btob);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Mainmenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button btob;
    }
}