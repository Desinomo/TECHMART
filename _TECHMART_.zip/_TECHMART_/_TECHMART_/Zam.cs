﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class Zam : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;
        public Zam()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadOrderDetails();
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private async void LoadOrderDetails()
        {
            try
            {
                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");
                var ordersCollection = database.GetCollection<BsonDocument>("Orders");
                var customersCollection = database.GetCollection<BsonDocument>("Customers");
                var productsCollection = database.GetCollection<BsonDocument>("products");

                var filter = Builders<BsonDocument>.Filter.Eq("completezam", false);
                var orderDetails = await orderDetailsCollection.Find(filter).ToListAsync();
                DataTable dt = new DataTable();
                dt.Columns.Add("OrderNumber", typeof(string));     // Номер замовлення
                dt.Columns.Add("CustomerName", typeof(string));    // Ім'я клієнта
                dt.Columns.Add("ProductName", typeof(string));     // Назва продукту
                dt.Columns.Add("Quantity", typeof(int));           // Кількість
                dt.Columns.Add("OrderDate", typeof(DateTime));     // Дата замовлення
                dt.Columns.Add("Completezam", typeof(string));     // Статус замовлення

                foreach (var orderDetail in orderDetails)
                {
                    // Отримуємо ID замовлення
                    var orderId = orderDetail["order_id"].ToString();

                    // Отримуємо замовлення по ID
                    var order = await ordersCollection.Find(new BsonDocument { { "order_id", orderId } }).FirstOrDefaultAsync();
                    DateTime orderDate = order?["date"].ToLocalTime() ?? DateTime.MinValue;

                    // Отримуємо ID клієнта (перевіряємо на ObjectId)
                    var customerIdStr = order?["customer_id"].ToString();
                    ObjectId customerId = ObjectId.TryParse(customerIdStr, out var parsedCustomerId) ? parsedCustomerId : ObjectId.Empty;

                    // Отримуємо ім'я клієнта по customer_id
                    var customer = await customersCollection.Find(new BsonDocument { { "_id", customerId } }).FirstOrDefaultAsync();
                    string customerName = customer?["first_name"]?.ToString() ?? "Невідомо";  // Використовуємо null-умовний оператор

                    // Отримуємо ID продукту (перевіряємо на ObjectId)
                    var productIdStr = orderDetail["product_id"].ToString();
                    ObjectId productId = ObjectId.TryParse(productIdStr, out var parsedProductId) ? parsedProductId : ObjectId.Empty;

                    // Отримуємо назву продукту по product_id
                    var product = await productsCollection.Find(new BsonDocument { { "_id", productId } }).FirstOrDefaultAsync();
                    string productName = product?["name"]?.ToString() ?? "Невідомо";  // Використовуємо null-умовний оператор

                    // Отримуємо кількість продукту
                    int quantity = orderDetail["quantity"].ToInt32();

                    // Отримуємо значення поля completezam
                    bool completezam = orderDetail["completezam"].ToBoolean();

                    // Якщо completezam = false, показуємо "Ні", інакше "Так"
                    string completezamStatus = completezam ? "Так" : "Ні";

                    // Додаємо рядок в DataTable, включаючи номер замовлення
                    dt.Rows.Add(orderId, customerName, productName, quantity, orderDate, completezamStatus);
                }
                dt.DefaultView.Sort = "OrderNumber ASC";
                dtz.DataSource = dt;
                dtz.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні даних: " + ex.Message);
            }
        }
        private void be_Click(object sender, EventArgs e)
        {
            Mainmenu mainMenu = new Mainmenu();
            mainMenu.Show();
            this.Close();
        }

        private void ba_Click(object sender, EventArgs e)
        {
            ZamAdd ZamAddForm = new ZamAdd();
            ZamAddForm.DataUpdated += LoadOrderDetails;
            ZamAddForm.Show();
        }

        private void bd_Click(object sender, EventArgs e)
        {
            ZamDelete ZamDeleteForm = new ZamDelete();
            ZamDeleteForm.DataUpdated += LoadOrderDetails;
            ZamDeleteForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ZamSearch ZamSearchForm = new ZamSearch();
            ZamSearchForm.DataUpdated += LoadOrderDetails;
            ZamSearchForm.Show();
        }

        private void bz_Click(object sender, EventArgs e)
        {
            ZamComplete ZamCompleteForm = new ZamComplete();
            ZamCompleteForm.DataUpdated += LoadOrderDetails;
            ZamCompleteForm.Show();
        }

        private async void dtz_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    string orderId = dtz.Rows[e.RowIndex].Cells["OrderNumber"].Value.ToString();

                    var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");
                    var productsCollection = database.GetCollection<BsonDocument>("products");

                    var filter = Builders<BsonDocument>.Filter.Eq("order_id", orderId);
                    var orderDetails = await orderDetailsCollection.Find(filter).ToListAsync();

                    decimal totalPrice = 0;
                    string message = $"Номер замовлення: {orderId}\n\n";

                    foreach (var orderDetail in orderDetails)
                    {
                        var productIdStr = orderDetail["product_id"].ToString();
                        ObjectId productId = ObjectId.TryParse(productIdStr, out var parsedProductId) ? parsedProductId : ObjectId.Empty;

                        var product = await productsCollection.Find(new BsonDocument { { "_id", productId } }).FirstOrDefaultAsync();

                        if (product != null)
                        {
                            string productName = product["name"].ToString();
                            decimal productPrice = product["price"].ToDecimal();
                            int quantity = orderDetail["quantity"].ToInt32();
                            decimal itemTotal = productPrice * quantity;

                            message += $"{productName} - {quantity} шт. x {productPrice} грн = {itemTotal} грн\n";
                            totalPrice += itemTotal;
                        }
                    }

                    message += $"\nЗагальна вартість: {totalPrice} грн";

                    MessageBox.Show(message, "Інформація про замовлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при обчисленні вартості замовлення: " + ex.Message);
            }
        }

    }
}
