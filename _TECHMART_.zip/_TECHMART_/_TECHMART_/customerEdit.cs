﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class customerEdit : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        private string originalEmail;
        public event Action DataUpdated;

        public customerEdit(string firstName, string lastName, string email)
        {
            InitializeComponent();
            InitializeMongoDB();

            txf.Text = firstName;
            txl.Text = lastName;
            txe.Text = email;

            originalEmail = email; 
        }

        private void InitializeMongoDB()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка підключення до MongoDB: {ex.Message}");
            }
        }

        private async void bk_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txf.Text) || string.IsNullOrEmpty(txl.Text) || string.IsNullOrEmpty(txe.Text))
                {
                    MessageBox.Show("Будь ласка, заповніть всі поля.");
                    return;
                }

                var collection = database.GetCollection<BsonDocument>("Customers");
                var filter = Builders<BsonDocument>.Filter.Eq("email", originalEmail);
                var update = Builders<BsonDocument>.Update
                    .Set("first_name", txf.Text)
                    .Set("last_name", txl.Text)
                    .Set("email", txe.Text);

                var result = await collection.UpdateOneAsync(filter, update);

                if (result.ModifiedCount > 0)
                {
                    MessageBox.Show("Користувача успішно оновлено.");
                }
                else
                {
                    MessageBox.Show("Не вдалося оновити дані.");
            
                }
                DataUpdated?.Invoke();
                this.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при оновленні даних: {ex.Message}");
            }
        }
    }
}
