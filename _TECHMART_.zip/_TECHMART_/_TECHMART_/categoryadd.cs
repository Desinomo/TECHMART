﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _TECHMART_
{
    public partial class categoryadd : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;

        public categoryadd()
        {
            InitializeComponent();
        }

        public event Action DataUpdated;

        private async void btok_Click_1(object sender, EventArgs e)
        {
            string categoryName = txnk.Text.Trim();

            if (!string.IsNullOrEmpty(categoryName))
            {
                try
                {
                    const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                    var settings = MongoClientSettings.FromConnectionString(connectionUri);
                    settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                    mongoClient = new MongoClient(settings);

                    database = mongoClient.GetDatabase("_TECHMART_");
                    var collection = database.GetCollection<BsonDocument>("Categories");

                    var CategoriesDocument = new BsonDocument
                    {
                        { "name", categoryName },
                    };
                    await collection.InsertOneAsync(CategoriesDocument);
                    DataUpdated?.Invoke();

                    MessageBox.Show("Категорію додано до MongoDB!");

                    txnk.Clear();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка при додаванні: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, введіть назву категорії.");
            }
        }
    }
}