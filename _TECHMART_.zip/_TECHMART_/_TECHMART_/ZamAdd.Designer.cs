﻿namespace _TECHMART_
{
    partial class ZamAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txn = new TextBox();
            label6 = new Label();
            label5 = new Label();
            txq = new TextBox();
            cc = new ComboBox();
            label2 = new Label();
            label4 = new Label();
            label3 = new Label();
            ba = new Button();
            label1 = new Label();
            d = new DateTimePicker();
            cp = new ComboBox();
            SuspendLayout();
            // 
            // txn
            // 
            txn.BackColor = Color.Azure;
            txn.Cursor = Cursors.IBeam;
            txn.Location = new Point(241, 90);
            txn.Multiline = true;
            txn.Name = "txn";
            txn.Size = new Size(177, 26);
            txn.TabIndex = 38;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.Location = new Point(28, 293);
            label6.Name = "label6";
            label6.Size = new Size(102, 23);
            label6.TabIndex = 37;
            label6.Text = "Кількість";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.Location = new Point(28, 250);
            label5.Name = "label5";
            label5.Size = new Size(188, 23);
            label5.TabIndex = 36;
            label5.Text = "Дата замовлення";
            // 
            // txq
            // 
            txq.BackColor = Color.Azure;
            txq.Cursor = Cursors.IBeam;
            txq.Location = new Point(136, 290);
            txq.Multiline = true;
            txq.Name = "txq";
            txq.Size = new Size(282, 26);
            txq.TabIndex = 35;
            // 
            // cc
            // 
            cc.Cursor = Cursors.Hand;
            cc.FormattingEnabled = true;
            cc.Location = new Point(136, 142);
            cc.Name = "cc";
            cc.Size = new Size(282, 23);
            cc.TabIndex = 32;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(28, 93);
            label2.Name = "label2";
            label2.Size = new Size(207, 23);
            label2.TabIndex = 31;
            label2.Text = "Номер замовлення";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(28, 196);
            label4.Name = "label4";
            label4.Size = new Size(97, 23);
            label4.TabIndex = 30;
            label4.Text = "Продукт";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(28, 142);
            label3.Name = "label3";
            label3.Size = new Size(75, 23);
            label3.TabIndex = 29;
            label3.Text = "Клієнт";
            // 
            // ba
            // 
            ba.BackColor = Color.Azure;
            ba.Cursor = Cursors.Hand;
            ba.FlatStyle = FlatStyle.Popup;
            ba.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ba.Location = new Point(106, 338);
            ba.Name = "ba";
            ba.Size = new Size(263, 40);
            ba.TabIndex = 28;
            ba.Text = "Створити замовлення";
            ba.UseVisualStyleBackColor = false;
            ba.Click += ba_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(77, 36);
            label1.Name = "label1";
            label1.Size = new Size(319, 28);
            label1.TabIndex = 27;
            label1.Text = "Додавання Замовлення:";
            label1.Click += label1_Click;
            // 
            // d
            // 
            d.Cursor = Cursors.Hand;
            d.Location = new Point(222, 250);
            d.Name = "d";
            d.Size = new Size(196, 23);
            d.TabIndex = 39;
            // 
            // cp
            // 
            cp.Cursor = Cursors.Hand;
            cp.FormattingEnabled = true;
            cp.Location = new Point(136, 200);
            cp.Name = "cp";
            cp.Size = new Size(282, 23);
            cp.TabIndex = 40;
            // 
            // ZamAdd
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(444, 427);
            Controls.Add(cp);
            Controls.Add(d);
            Controls.Add(txn);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txq);
            Controls.Add(cc);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(ba);
            Controls.Add(label1);
            Name = "ZamAdd";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txn;
        private Label label6;
        private Label label5;
        private TextBox txq;
        private TextBox txc;
        private ComboBox ck;
        private ComboBox cc;
        private Label label2;
        private Label label4;
        private Label label3;
        private Button ba;
        private Label label1;
        private DateTimePicker d;
        private ComboBox cp;
    }
}