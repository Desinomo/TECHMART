﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class Mainmenu : Form
    {
        public Mainmenu()
        {
            InitializeComponent();
        }

        private void btob_Click(object sender, EventArgs e)
        {
            brends brends = new brends();

            brends.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            customers customersForm = new customers();
            customersForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Zam ZamForm = new Zam();
            ZamForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Zvit ZvitForm = new Zvit();
            ZvitForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Products ProductsForm = new Products();
            ProductsForm.Show();
            this.Hide();
        }
    }
}
