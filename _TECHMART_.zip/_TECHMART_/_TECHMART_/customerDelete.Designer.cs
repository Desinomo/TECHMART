﻿namespace _TECHMART_
{
    partial class customerDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txf = new TextBox();
            label2 = new Label();
            btod = new Button();
            txl = new TextBox();
            txe = new TextBox();
            label4 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(259, 28);
            label1.TabIndex = 3;
            label1.Text = "Видалення клієнту:";
            // 
            // txf
            // 
            txf.BackColor = Color.Azure;
            txf.Cursor = Cursors.IBeam;
            txf.Location = new Point(103, 51);
            txf.Multiline = true;
            txf.Name = "txf";
            txf.Size = new Size(161, 26);
            txf.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(18, 51);
            label2.Name = "label2";
            label2.Size = new Size(53, 25);
            label2.TabIndex = 6;
            label2.Text = "Ім'я";
            // 
            // btod
            // 
            btod.BackColor = Color.Azure;
            btod.Cursor = Cursors.Hand;
            btod.FlatStyle = FlatStyle.Popup;
            btod.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btod.Location = new Point(12, 171);
            btod.Name = "btod";
            btod.Size = new Size(252, 40);
            btod.TabIndex = 7;
            btod.Text = "Видалити";
            btod.UseVisualStyleBackColor = false;
            btod.Click += btod_Click_1;
            // 
            // txl
            // 
            txl.BackColor = Color.Azure;
            txl.Cursor = Cursors.IBeam;
            txl.Location = new Point(136, 87);
            txl.Multiline = true;
            txl.Name = "txl";
            txl.Size = new Size(128, 26);
            txl.TabIndex = 9;
            // 
            // txe
            // 
            txe.BackColor = Color.Azure;
            txe.Cursor = Cursors.IBeam;
            txe.Location = new Point(103, 128);
            txe.Multiline = true;
            txe.Name = "txe";
            txe.Size = new Size(161, 26);
            txe.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(18, 129);
            label4.Name = "label4";
            label4.Size = new Size(72, 25);
            label4.TabIndex = 11;
            label4.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Sans Unicode", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.Location = new Point(18, 88);
            label5.Name = "label5";
            label5.Size = new Size(119, 25);
            label5.TabIndex = 12;
            label5.Text = "Прізвище";
            // 
            // customerDelete
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(276, 221);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txe);
            Controls.Add(txl);
            Controls.Add(btod);
            Controls.Add(label2);
            Controls.Add(txf);
            Controls.Add(label1);
            Name = "customerDelete";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txf;
        private Label label2;
        private Button btod;
        private TextBox txl;
        private TextBox txe;
        private Label label4;
        private Label label5;
    }
}