﻿namespace _TECHMART_
{
    partial class ZamDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cp = new ComboBox();
            txn = new TextBox();
            label2 = new Label();
            label4 = new Label();
            ba = new Button();
            label1 = new Label();
            rb = new CheckBox();
            SuspendLayout();
            // 
            // cp
            // 
            cp.BackColor = Color.Azure;
            cp.Cursor = Cursors.Hand;
            cp.FormattingEnabled = true;
            cp.Location = new Point(133, 140);
            cp.Name = "cp";
            cp.Size = new Size(282, 23);
            cp.TabIndex = 52;
            // 
            // txn
            // 
            txn.BackColor = Color.Azure;
            txn.Cursor = Cursors.IBeam;
            txn.Location = new Point(238, 56);
            txn.Multiline = true;
            txn.Name = "txn";
            txn.Size = new Size(177, 26);
            txn.TabIndex = 50;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(25, 59);
            label2.Name = "label2";
            label2.Size = new Size(207, 23);
            label2.TabIndex = 45;
            label2.Text = "Номер замовлення";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(25, 140);
            label4.Name = "label4";
            label4.Size = new Size(97, 23);
            label4.TabIndex = 44;
            label4.Text = "Продукт";
            label4.Click += label4_Click_1;
            // 
            // ba
            // 
            ba.BackColor = Color.Azure;
            ba.Cursor = Cursors.Hand;
            ba.FlatStyle = FlatStyle.Popup;
            ba.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ba.Location = new Point(93, 178);
            ba.Name = "ba";
            ba.Size = new Size(263, 40);
            ba.TabIndex = 42;
            ba.Text = "Видалити";
            ba.UseVisualStyleBackColor = false;
            ba.Click += ba_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(74, 9);
            label1.Name = "label1";
            label1.Size = new Size(306, 28);
            label1.TabIndex = 41;
            label1.Text = "Видалення замовлення";
            // 
            // rb
            // 
            rb.AutoSize = true;
            rb.Cursor = Cursors.Hand;
            rb.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            rb.Location = new Point(25, 97);
            rb.Name = "rb";
            rb.Size = new Size(298, 27);
            rb.TabIndex = 54;
            rb.Text = "Видалити все замовлення";
            rb.UseVisualStyleBackColor = true;
            // 
            // ZamDelete
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(432, 230);
            Controls.Add(rb);
            Controls.Add(cp);
            Controls.Add(txn);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(ba);
            Controls.Add(label1);
            Name = "ZamDelete";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cp;
        private TextBox txn;
        private Label label2;
        private Label label4;
        private Button ba;
        private Label label1;
        private CheckBox rb;
    }
}