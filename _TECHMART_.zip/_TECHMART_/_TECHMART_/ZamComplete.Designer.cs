﻿namespace _TECHMART_
{
    partial class ZamComplete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cp = new ComboBox();
            label4 = new Label();
            ba = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // cp
            // 
            cp.Cursor = Cursors.Hand;
            cp.FormattingEnabled = true;
            cp.Location = new Point(100, 58);
            cp.Name = "cp";
            cp.Size = new Size(282, 23);
            cp.TabIndex = 60;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(51, 58);
            label4.Name = "label4";
            label4.Size = new Size(29, 23);
            label4.TabIndex = 57;
            label4.Text = "№";
            // 
            // ba
            // 
            ba.BackColor = Color.Azure;
            ba.Cursor = Cursors.Hand;
            ba.FlatStyle = FlatStyle.Popup;
            ba.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ba.Location = new Point(86, 98);
            ba.Name = "ba";
            ba.Size = new Size(263, 40);
            ba.TabIndex = 56;
            ba.Text = "Завершити замовлення";
            ba.UseVisualStyleBackColor = false;
            ba.Click += ba_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(30, 9);
            label1.Name = "label1";
            label1.Size = new Size(369, 28);
            label1.TabIndex = 55;
            label1.Text = "Виберіть номер замовлення";
            // 
            // ZamComplete
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(423, 147);
            Controls.Add(cp);
            Controls.Add(label4);
            Controls.Add(ba);
            Controls.Add(label1);
            Name = "ZamComplete";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cp;
        private Label label4;
        private Button ba;
        private Label label1;
    }
}