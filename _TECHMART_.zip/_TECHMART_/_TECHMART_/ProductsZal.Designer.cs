﻿namespace _TECHMART_
{
    partial class ProductsZal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txz = new TextBox();
            cz = new ComboBox();
            label2 = new Label();
            label3 = new Label();
            bz = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // txz
            // 
            txz.BackColor = Color.Azure;
            txz.Cursor = Cursors.IBeam;
            txz.Location = new Point(159, 103);
            txz.Multiline = true;
            txz.Name = "txz";
            txz.Size = new Size(177, 26);
            txz.TabIndex = 32;
            // 
            // cz
            // 
            cz.BackColor = Color.Azure;
            cz.Cursor = Cursors.Hand;
            cz.FormattingEnabled = true;
            cz.Location = new Point(159, 57);
            cz.Name = "cz";
            cz.Size = new Size(177, 23);
            cz.TabIndex = 31;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(39, 57);
            label2.Name = "label2";
            label2.Size = new Size(70, 23);
            label2.TabIndex = 30;
            label2.Text = "Назва";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(39, 106);
            label3.Name = "label3";
            label3.Size = new Size(102, 23);
            label3.TabIndex = 29;
            label3.Text = "Кількість";
            // 
            // bz
            // 
            bz.BackColor = Color.Azure;
            bz.Cursor = Cursors.Hand;
            bz.FlatStyle = FlatStyle.Popup;
            bz.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bz.Location = new Point(83, 148);
            bz.Name = "bz";
            bz.Size = new Size(179, 40);
            bz.TabIndex = 28;
            bz.Text = "Змінити";
            bz.UseVisualStyleBackColor = false;
            bz.Click += bz_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(63, 9);
            label1.Name = "label1";
            label1.Size = new Size(260, 28);
            label1.TabIndex = 27;
            label1.Text = "Змінення залишків:";
            // 
            // ProductsZal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(357, 200);
            Controls.Add(txz);
            Controls.Add(cz);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(bz);
            Controls.Add(label1);
            Name = "ProductsZal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txz;
        private ComboBox cz;
        private Label label2;
        private Label label3;
        private Button bz;
        private Label label1;
    }
}