﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class customerAdd : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;

        public customerAdd()
        {
            InitializeComponent();
            InitializeMongoDB();
        }

        private void InitializeMongoDB()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка підключення до MongoDB: {ex.Message}");
            }
        }

        private async void bk_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txf.Text) || string.IsNullOrEmpty(txl.Text) || string.IsNullOrEmpty(txe.Text))
                {
                    MessageBox.Show("Будь ласка, заповніть всі поля.");
                    return;
                }

                var collection = database.GetCollection<BsonDocument>("Customers");

                var newCustomer = new BsonDocument
            {
                { "first_name", txf.Text },
                { "last_name", txl.Text },
                { "email", txe.Text }
            };

                await collection.InsertOneAsync(newCustomer);
                DataUpdated?.Invoke(); 
                MessageBox.Show("Користувача успішно додано.");
                txf.Clear();
                txl.Clear();
                txe.Clear();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при додаванні користувача: {ex.Message}");
            }
        }
    }

}
