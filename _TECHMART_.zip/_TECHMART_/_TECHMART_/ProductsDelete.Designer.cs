﻿namespace _TECHMART_
{
    partial class ProductsDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btod = new Button();
            txnb = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // btod
            // 
            btod.BackColor = Color.Azure;
            btod.Cursor = Cursors.Hand;
            btod.FlatStyle = FlatStyle.Popup;
            btod.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btod.Location = new Point(12, 103);
            btod.Name = "btod";
            btod.Size = new Size(252, 40);
            btod.TabIndex = 10;
            btod.Text = "Видалити";
            btod.UseVisualStyleBackColor = false;
            btod.Click += btod_Click_1;
            // 
            // txnb
            // 
            txnb.BackColor = Color.Azure;
            txnb.Cursor = Cursors.IBeam;
            txnb.Location = new Point(103, 55);
            txnb.Multiline = true;
            txnb.Name = "txnb";
            txnb.Size = new Size(161, 26);
            txnb.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(12, 55);
            label2.Name = "label2";
            label2.Size = new Size(85, 25);
            label2.TabIndex = 8;
            label2.Text = "Назва:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(289, 28);
            label1.TabIndex = 7;
            label1.Text = "Видалення Продукту:";
            // 
            // ProductsDelete
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(297, 159);
            Controls.Add(btod);
            Controls.Add(txnb);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ProductsDelete";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btod;
        private TextBox txnb;
        private Label label2;
        private Label label1;
    }
}