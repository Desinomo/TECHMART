﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class customers : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;

        private string selectedFirstName;
        private string selectedLastName;
        private string selectedEmail;

        public customers()
        {
            InitializeComponent();
            LoadData();
        }
        private async void LoadData()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");

                var collection = database.GetCollection<BsonDocument>("Customers");
                var customers = await collection.Find(new BsonDocument()).ToListAsync();

                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("First Name");
                dataTable.Columns.Add("Last Name");
                dataTable.Columns.Add("Email");

                foreach (var customer in customers)
                {
                    DataRow row = dataTable.NewRow();
                    row["First Name"] = customer["first_name"].ToString();
                    row["Last Name"] = customer["last_name"].ToString();
                    row["Email"] = customer["email"].ToString();
                    dataTable.Rows.Add(row);
                }

                dtk.DataSource = dataTable;
                dtk.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dtk.Columns["First Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dtk.Columns["Last Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dtk.Columns["Email"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні даних: " + ex.Message);
            }
        }
        private void btAddCustomer_Click(object sender, EventArgs e)
        {
            customerAdd customerAddForm = new customerAdd();
            customerAddForm.DataUpdated += LoadData; 
            customerAddForm.Show();
        }

        private void btDeleteCustomer_Click(object sender, EventArgs e)
        {
            customerDelete customerDeleteForm = new customerDelete();
            customerDeleteForm.Show();
        }


        private void btEditCustomer_Click(object sender, EventArgs e)
        {
            if (dtk.SelectedRows.Count > 0)
            {
                customerEdit customerEditForm = new customerEdit(selectedFirstName, selectedLastName, selectedEmail);
                customerEditForm.DataUpdated += LoadData; 
                customerEditForm.Show();
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть клієнта для редагування.");
            }
        }

        private void bak_Click(object sender, EventArgs e)
        {
            customerAdd customerAddForm = new customerAdd();
            customerAddForm.DataUpdated += LoadData; 
            customerAddForm.Show();
        }

        private void bdk_Click(object sender, EventArgs e)
        {
            customerDelete customerDeleteForm = new customerDelete();
            customerDeleteForm.DataUpdated += LoadData;
            customerDeleteForm.Show();
        }

        private void dtk_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedFirstName = dtk.Rows[e.RowIndex].Cells["First Name"].Value.ToString();
                selectedLastName = dtk.Rows[e.RowIndex].Cells["Last Name"].Value.ToString();
                selectedEmail = dtk.Rows[e.RowIndex].Cells["Email"].Value.ToString();

                customerEdit customerEditForm = new customerEdit(selectedFirstName, selectedLastName, selectedEmail);
                customerEditForm.DataUpdated += LoadData;
                customerEditForm.Show();
            }
        }

        private void be_Click(object sender, EventArgs e)
        {
            Mainmenu mainMenu = new Mainmenu();
            mainMenu.Show();
            this.Close();
        }
    }
}