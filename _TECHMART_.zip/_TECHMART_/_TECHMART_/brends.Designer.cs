﻿namespace _TECHMART_
{
    partial class brends
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            dtgb = new DataGridView();
            be = new Button();
            ba = new Button();
            dtgc = new DataGridView();
            button2 = new Button();
            l = new Label();
            label1 = new Label();
            button1 = new Button();
            button3 = new Button();
            ((System.ComponentModel.ISupportInitialize)dtgb).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dtgc).BeginInit();
            SuspendLayout();
            // 
            // dtgb
            // 
            dtgb.BackgroundColor = Color.Azure;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Azure;
            dataGridViewCellStyle1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dtgb.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dtgb.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Azure;
            dataGridViewCellStyle2.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dtgb.DefaultCellStyle = dataGridViewCellStyle2;
            dtgb.GridColor = SystemColors.ActiveCaptionText;
            dtgb.ImeMode = ImeMode.NoControl;
            dtgb.Location = new Point(12, 37);
            dtgb.MultiSelect = false;
            dtgb.Name = "dtgb";
            dtgb.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.Azure;
            dataGridViewCellStyle3.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dtgb.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dtgb.RowHeadersVisible = false;
            dtgb.RowTemplate.DefaultCellStyle.BackColor = Color.Azure;
            dtgb.RowTemplate.DefaultCellStyle.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtgb.Size = new Size(344, 185);
            dtgb.StandardTab = true;
            dtgb.TabIndex = 0;
            dtgb.UseWaitCursor = true;
            // 
            // be
            // 
            be.BackColor = Color.Azure;
            be.Cursor = Cursors.Hand;
            be.FlatStyle = FlatStyle.Popup;
            be.Font = new Font("Bookman Old Style", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            be.Location = new Point(12, 9);
            be.Name = "be";
            be.Size = new Size(29, 22);
            be.TabIndex = 1;
            be.Text = "<-";
            be.UseVisualStyleBackColor = false;
            be.Click += be_Click;
            // 
            // ba
            // 
            ba.BackColor = Color.Azure;
            ba.Cursor = Cursors.Hand;
            ba.FlatStyle = FlatStyle.Popup;
            ba.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ba.Location = new Point(391, 37);
            ba.Name = "ba";
            ba.Size = new Size(335, 92);
            ba.TabIndex = 4;
            ba.Text = "Додати бренд";
            ba.UseVisualStyleBackColor = false;
            ba.Click += ba_Click;
            // 
            // dtgc
            // 
            dtgc.BackgroundColor = Color.Azure;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.Azure;
            dataGridViewCellStyle4.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dtgc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dtgc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.Azure;
            dataGridViewCellStyle5.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dtgc.DefaultCellStyle = dataGridViewCellStyle5;
            dtgc.GridColor = SystemColors.ControlText;
            dtgc.ImeMode = ImeMode.NoControl;
            dtgc.Location = new Point(12, 251);
            dtgc.MultiSelect = false;
            dtgc.Name = "dtgc";
            dtgc.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.Azure;
            dataGridViewCellStyle6.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dtgc.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dtgc.Size = new Size(344, 185);
            dtgc.TabIndex = 5;
            // 
            // button2
            // 
            button2.BackColor = Color.Azure;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button2.Location = new Point(391, 342);
            button2.Name = "button2";
            button2.Size = new Size(335, 94);
            button2.TabIndex = 7;
            button2.Text = "Видалити категорію";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // l
            // 
            l.AutoSize = true;
            l.Font = new Font("Lucida Sans Unicode", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            l.Location = new Point(297, 18);
            l.Name = "l";
            l.Size = new Size(59, 16);
            l.TabIndex = 8;
            l.Text = "Бренди";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(286, 232);
            label1.Name = "label1";
            label1.Size = new Size(70, 16);
            label1.TabIndex = 9;
            label1.Text = "Категорії";
            // 
            // button1
            // 
            button1.BackColor = Color.Azure;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button1.Location = new Point(391, 251);
            button1.Name = "button1";
            button1.Size = new Size(335, 85);
            button1.TabIndex = 10;
            button1.Text = "Додати категорію";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Azure;
            button3.Cursor = Cursors.Hand;
            button3.FlatAppearance.BorderColor = Color.Black;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button3.Location = new Point(391, 135);
            button3.Name = "button3";
            button3.Size = new Size(335, 87);
            button3.TabIndex = 11;
            button3.Text = "Видалити бренд";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // brends
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(738, 455);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(l);
            Controls.Add(button2);
            Controls.Add(dtgc);
            Controls.Add(ba);
            Controls.Add(be);
            Controls.Add(dtgb);
            Name = "brends";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)dtgb).EndInit();
            ((System.ComponentModel.ISupportInitialize)dtgc).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dtgb;
        private Button be;
        private Button ba;
        private DataGridView dtgc;
        private Button button2;
        private Label l;
        private Label label1;
        private Button button1;
        private Button button3;
    }
}