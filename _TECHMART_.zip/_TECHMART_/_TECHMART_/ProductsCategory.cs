﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ProductsCategory : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        private IMongoCollection<BsonDocument> brandsCollection;
        private IMongoCollection<BsonDocument> productsCollection;
        private IMongoCollection<BsonDocument> categoriesCollection;

        public ProductsCategory()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadCategories();
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");

                brandsCollection = database.GetCollection<BsonDocument>("brands");
                productsCollection = database.GetCollection<BsonDocument>("products");
                categoriesCollection = database.GetCollection<BsonDocument>("Categories");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private async void LoadCategories()
        {
            try
            {
                var categories = await categoriesCollection.Find(new BsonDocument()).ToListAsync();
                DataTable categoryTable = new DataTable();
                categoryTable.Columns.Add("category_id", typeof(string));
                categoryTable.Columns.Add("name", typeof(string));

                foreach (var category in categories)
                {
                    var categoryId = category["_id"].AsObjectId;
                    var categoryName = category["name"].ToString();
                    categoryTable.Rows.Add(categoryId, categoryName);
                }

                cb.DataSource = categoryTable;
                cb.DisplayMember = "name";
                cb.ValueMember = "category_id";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка завантаження категорій: " + ex.Message);
            }
        }

        private async Task<string> GetBrandName(ObjectId brandId)
        {
            if (!brandId.Equals(ObjectId.Empty))
            {
                var brand = await brandsCollection.Find(Builders<BsonDocument>.Filter.Eq("_id", brandId)).FirstOrDefaultAsync();
                return brand?["name"]?.ToString();
            }
            return null;
        }

        private async void bc_Click_1(object sender, EventArgs e)
        {
            try
            {
                var selectedCategoryId = cb.SelectedValue.ToString();
                var filter = Builders<BsonDocument>.Filter.Eq("category_id", selectedCategoryId);
                var filteredProducts = await productsCollection.Find(filter).ToListAsync();

                DataTable productTable = new DataTable();
                productTable.Columns.Add("name", typeof(string));
                productTable.Columns.Add("price", typeof(decimal));
                productTable.Columns.Add("quantity", typeof(int));
                productTable.Columns.Add("brand", typeof(string));

                foreach (var product in filteredProducts)
                {
                    var productName = product["name"].ToString();
                    var productPrice = product["price"].ToDecimal();
                    var productQuantity = product["quantity"].ToInt32();
                    var brandId = product["brand_id"].ToString();

                    var brandObjectId = ObjectId.TryParse(brandId, out var parsedBrandId) ? parsedBrandId : ObjectId.Empty;
                    var brandName = await GetBrandName(parsedBrandId);

                    productTable.Rows.Add(productName, productPrice, productQuantity, brandName ?? "Не вказано");
                }

                dtc.DataSource = productTable;
                dtc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (dtc.Columns.Contains("product_id"))
                {
                    dtc.Columns["product_id"].Visible = false;
                }

                var selectedCategoryName = cb.Text;
                l.Text = selectedCategoryName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні продуктів: " + ex.Message);
            }
        }

        private void be_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}