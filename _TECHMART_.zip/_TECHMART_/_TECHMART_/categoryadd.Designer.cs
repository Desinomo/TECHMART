﻿namespace _TECHMART_
{
    partial class categoryadd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txnk = new TextBox();
            btok = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(23, 9);
            label1.Name = "label1";
            label1.Size = new Size(285, 28);
            label1.TabIndex = 2;
            label1.Text = "Додавання категорії:";
            // 
            // txnk
            // 
            txnk.BackColor = Color.Azure;
            txnk.Cursor = Cursors.IBeam;
            txnk.Location = new Point(120, 64);
            txnk.Multiline = true;
            txnk.Name = "txnk";
            txnk.Size = new Size(198, 26);
            txnk.TabIndex = 3;
            // 
            // btok
            // 
            btok.BackColor = Color.Azure;
            btok.Cursor = Cursors.Hand;
            btok.FlatStyle = FlatStyle.Popup;
            btok.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btok.Location = new Point(80, 115);
            btok.Name = "btok";
            btok.Size = new Size(179, 40);
            btok.TabIndex = 6;
            btok.Text = "Створити";
            btok.UseVisualStyleBackColor = false;
            btok.Click += btok_Click_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(12, 67);
            label2.Name = "label2";
            label2.Size = new Size(77, 23);
            label2.TabIndex = 7;
            label2.Text = "Назва:";
            // 
            // categoryadd
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(330, 167);
            Controls.Add(label2);
            Controls.Add(btok);
            Controls.Add(txnk);
            Controls.Add(label1);
            Name = "categoryadd";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txnk;
        private Button btok;
        private Label label2;
    }
}