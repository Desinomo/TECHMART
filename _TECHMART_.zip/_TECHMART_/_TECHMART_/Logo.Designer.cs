﻿namespace _TECHMART_
{
    partial class Logo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btom = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btom
            // 
            btom.BackColor = Color.Azure;
            btom.Cursor = Cursors.Hand;
            btom.FlatStyle = FlatStyle.Popup;
            btom.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btom.Location = new Point(25, 530);
            btom.Name = "btom";
            btom.Size = new Size(493, 56);
            btom.TabIndex = 6;
            btom.Text = "Вхід";
            btom.UseVisualStyleBackColor = false;
            btom.Click += btom_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.das;
            pictureBox1.Location = new Point(25, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(493, 500);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // Logo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PowderBlue;
            ClientSize = new Size(536, 604);
            Controls.Add(btom);
            Controls.Add(pictureBox1);
            Name = "Logo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button btom;
        private PictureBox pictureBox1;
    }
}