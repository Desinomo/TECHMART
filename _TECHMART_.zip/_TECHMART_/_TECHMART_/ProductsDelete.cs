﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ProductsDelete : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;

        public ProductsDelete()
        {
            InitializeComponent();
        }
        private async void btod_Click_1(object sender, EventArgs e)
        {
            string productName = txnb.Text.Trim();

            if (!string.IsNullOrEmpty(productName))
            {
                try
                {
                    const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                    var settings = MongoClientSettings.FromConnectionString(connectionUri);
                    settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                    mongoClient = new MongoClient(settings);

                    database = mongoClient.GetDatabase("_TECHMART_");
                    var collection = database.GetCollection<BsonDocument>("products");

                    var deleteResult = await collection.DeleteOneAsync(Builders<BsonDocument>.Filter.Eq("name", productName));

                    if (deleteResult.DeletedCount > 0)
                    {
                        DataUpdated?.Invoke();
                        MessageBox.Show("Продукт успішно видалено!", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txnb.Clear();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Продукт не знайдено!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка при видаленні: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, введіть назву продукту для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
