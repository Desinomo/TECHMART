﻿namespace _TECHMART_
{
    partial class ProductsAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label4 = new Label();
            label3 = new Label();
            ba = new Button();
            label1 = new Label();
            cb = new ComboBox();
            ck = new ComboBox();
            txc = new TextBox();
            txk = new TextBox();
            label5 = new Label();
            label6 = new Label();
            txn = new TextBox();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(19, 76);
            label2.Name = "label2";
            label2.Size = new Size(70, 23);
            label2.TabIndex = 19;
            label2.Text = "Назва";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(19, 179);
            label4.Name = "label4";
            label4.Size = new Size(110, 23);
            label4.TabIndex = 17;
            label4.Text = "Категорія";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(19, 125);
            label3.Name = "label3";
            label3.Size = new Size(74, 23);
            label3.TabIndex = 15;
            label3.Text = "Бренд";
            // 
            // ba
            // 
            ba.BackColor = Color.Azure;
            ba.Cursor = Cursors.Hand;
            ba.FlatStyle = FlatStyle.Popup;
            ba.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ba.Location = new Point(80, 334);
            ba.Name = "ba";
            ba.Size = new Size(179, 40);
            ba.TabIndex = 14;
            ba.Text = "Додати";
            ba.UseVisualStyleBackColor = false;
            ba.Click += ba_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(28, 19);
            label1.Name = "label1";
            label1.Size = new Size(292, 28);
            label1.TabIndex = 12;
            label1.Text = "Додавання Продукта:";
            // 
            // cb
            // 
            cb.BackColor = Color.Azure;
            cb.Cursor = Cursors.Hand;
            cb.FormattingEnabled = true;
            cb.Location = new Point(143, 129);
            cb.Name = "cb";
            cb.Size = new Size(177, 23);
            cb.TabIndex = 20;
            // 
            // ck
            // 
            ck.BackColor = Color.Azure;
            ck.Cursor = Cursors.Hand;
            ck.FormattingEnabled = true;
            ck.Location = new Point(143, 179);
            ck.Name = "ck";
            ck.Size = new Size(177, 23);
            ck.TabIndex = 21;
            // 
            // txc
            // 
            txc.BackColor = Color.Azure;
            txc.Cursor = Cursors.IBeam;
            txc.Location = new Point(143, 228);
            txc.Multiline = true;
            txc.Name = "txc";
            txc.Size = new Size(177, 26);
            txc.TabIndex = 22;
            // 
            // txk
            // 
            txk.BackColor = Color.Azure;
            txk.Cursor = Cursors.IBeam;
            txk.Location = new Point(143, 270);
            txk.Multiline = true;
            txk.Name = "txk";
            txk.Size = new Size(177, 26);
            txk.TabIndex = 23;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.Location = new Point(19, 231);
            label5.Name = "label5";
            label5.Size = new Size(58, 23);
            label5.TabIndex = 24;
            label5.Text = "Ціна";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.Location = new Point(19, 273);
            label6.Name = "label6";
            label6.Size = new Size(102, 23);
            label6.TabIndex = 25;
            label6.Text = "Кількість";
            // 
            // txn
            // 
            txn.BackColor = Color.Azure;
            txn.Cursor = Cursors.IBeam;
            txn.Location = new Point(143, 76);
            txn.Multiline = true;
            txn.Name = "txn";
            txn.Size = new Size(177, 26);
            txn.TabIndex = 26;
            // 
            // ProductsAdd
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(339, 386);
            Controls.Add(txn);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txk);
            Controls.Add(txc);
            Controls.Add(ck);
            Controls.Add(cb);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(ba);
            Controls.Add(label1);
            Name = "ProductsAdd";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private TextBox txe;
        private Label label4;
        private TextBox txl;
        private Label label3;
        private Button ba;
        private TextBox txf;
        private Label label1;
        private ComboBox cb;
        private ComboBox ck;
        private TextBox txc;
        private TextBox txk;
        private Label label5;
        private Label label6;
        private TextBox txn;
    }
}