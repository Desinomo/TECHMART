﻿namespace _TECHMART_
{
    partial class customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            dtk = new DataGridView();
            bak = new Button();
            bdk = new Button();
            be = new Button();
            l = new Label();
            ((System.ComponentModel.ISupportInitialize)dtk).BeginInit();
            SuspendLayout();
            // 
            // dtk
            // 
            dtk.BackgroundColor = Color.Azure;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.Azure;
            dataGridViewCellStyle4.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dtk.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dtk.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.Azure;
            dataGridViewCellStyle5.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dtk.DefaultCellStyle = dataGridViewCellStyle5;
            dtk.GridColor = SystemColors.ActiveCaptionText;
            dtk.ImeMode = ImeMode.NoControl;
            dtk.Location = new Point(12, 58);
            dtk.MultiSelect = false;
            dtk.Name = "dtk";
            dtk.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.Azure;
            dataGridViewCellStyle6.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dtk.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dtk.RowHeadersVisible = false;
            dtk.RowTemplate.DefaultCellStyle.BackColor = Color.Azure;
            dtk.RowTemplate.DefaultCellStyle.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtk.Size = new Size(540, 336);
            dtk.StandardTab = true;
            dtk.TabIndex = 1;
            dtk.UseWaitCursor = true;
            dtk.CellClick += dtk_CellClick;
            // 
            // bak
            // 
            bak.BackColor = Color.Azure;
            bak.Cursor = Cursors.Hand;
            bak.FlatStyle = FlatStyle.Popup;
            bak.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bak.Location = new Point(287, 400);
            bak.Name = "bak";
            bak.Size = new Size(265, 38);
            bak.TabIndex = 5;
            bak.Text = "Зареєструвати клієнта";
            bak.UseVisualStyleBackColor = false;
            bak.Click += bak_Click;
            // 
            // bdk
            // 
            bdk.BackColor = Color.Azure;
            bdk.Cursor = Cursors.Hand;
            bdk.FlatAppearance.BorderColor = Color.Black;
            bdk.FlatStyle = FlatStyle.Popup;
            bdk.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bdk.Location = new Point(12, 400);
            bdk.Name = "bdk";
            bdk.Size = new Size(269, 38);
            bdk.TabIndex = 12;
            bdk.Text = "Видалити клієнта";
            bdk.UseVisualStyleBackColor = false;
            bdk.Click += bdk_Click;
            // 
            // be
            // 
            be.BackColor = Color.Azure;
            be.Cursor = Cursors.Hand;
            be.FlatStyle = FlatStyle.Popup;
            be.Font = new Font("Bookman Old Style", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            be.Location = new Point(12, 12);
            be.Name = "be";
            be.Size = new Size(29, 22);
            be.TabIndex = 13;
            be.Text = "<-";
            be.UseVisualStyleBackColor = false;
            be.Click += be_Click;
            // 
            // l
            // 
            l.AutoSize = true;
            l.Font = new Font("Lucida Sans Unicode", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            l.Location = new Point(218, 12);
            l.Name = "l";
            l.Size = new Size(123, 34);
            l.TabIndex = 14;
            l.Text = "Клієнти";
            // 
            // customers
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(564, 450);
            Controls.Add(l);
            Controls.Add(be);
            Controls.Add(bdk);
            Controls.Add(bak);
            Controls.Add(dtk);
            Name = "customers";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)dtk).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dtk;
        private Button bak;
        private Button bdk;
        private Button be;
        private Label l;
    }
}