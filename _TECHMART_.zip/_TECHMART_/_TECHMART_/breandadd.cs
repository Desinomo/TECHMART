﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class breandadd : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;

        public breandadd()
        {
            InitializeComponent();
        }
        public event Action DataUpdated;
        private async void btod_Click(object sender, EventArgs e)
        {
            string brandName = txnb.Text.Trim(); 
            string brandDescription = txob.Text.Trim();

            if (!string.IsNullOrEmpty(brandName) && !string.IsNullOrEmpty(brandDescription))
            {
                try
                {
                    const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                    var settings = MongoClientSettings.FromConnectionString(connectionUri);
                    settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                    mongoClient = new MongoClient(settings);
                    var result = await mongoClient.GetDatabase("admin").RunCommandAsync<BsonDocument>(new BsonDocument("ping", 1));
                    Console.WriteLine("Pinged your deployment. You successfully connected to MongoDB!");

                    database = mongoClient.GetDatabase("_TECHMART_");
                    var collection = database.GetCollection<BsonDocument>("brands");

                    var brandDocument = new BsonDocument
                    {
                        { "name", brandName },
                        { "description", brandDescription }
                    };

                    await collection.InsertOneAsync(brandDocument);
                    DataUpdated?.Invoke();
                    MessageBox.Show("Бренд додано до MongoDB!");

                    txnb.Clear();
                    txob.Clear();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка при додаванні: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, введіть назву та опис бренду.");
            }
        }

        private void txob_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
