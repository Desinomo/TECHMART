﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class Products : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;

        public Products()
        {
            InitializeComponent();
            LoadData();
        }
        private async void LoadData()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");

                var productCollection = database.GetCollection<BsonDocument>("products");

                var products = await productCollection.Find(new BsonDocument()).ToListAsync();

                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("Name");
                dataTable.Columns.Add("Category");
                dataTable.Columns.Add("Brand");
                dataTable.Columns.Add("Price");
                dataTable.Columns.Add("Quantity");

                foreach (var product in products)
                {
                    DataRow row = dataTable.NewRow();
                    row["Name"] = product["name"].ToString();

                    var categoryId = product["category_id"].ToString();
                    var categoryObjectId = ObjectId.TryParse(categoryId, out var parsedCategoryId) ? parsedCategoryId : ObjectId.Empty;
                    var categoryName = await GetCategoryName(categoryObjectId);
                    row["Category"] = categoryName ?? "Unknown";

                    var brandId = product["brand_id"].ToString();
                    var brandObjectId = ObjectId.TryParse(brandId, out var parsedBrandId) ? parsedBrandId : ObjectId.Empty;
                    var brandName = await GetBrandName(brandObjectId);
                    row["Brand"] = brandName ?? "Unknown";

                    row["Price"] = product["price"].ToInt32();
                    row["Quantity"] = product["quantity"].ToInt32();

                    dataTable.Rows.Add(row);
                }

                dte.DataSource = dataTable;
                dte.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні даних: " + ex.Message);
            }
        }

        private async Task<string> GetCategoryName(ObjectId categoryId)
        {
            if (!categoryId.Equals(ObjectId.Empty))
            {
                var categoryCollection = database.GetCollection<BsonDocument>("Categories");
                var category = await categoryCollection.Find(Builders<BsonDocument>.Filter.Eq("_id", categoryId)).FirstOrDefaultAsync();
                return category?["name"]?.ToString();
            }
            return null;
        }
        private async Task<string> GetBrandName(ObjectId brandId)
        {
            if (!brandId.Equals(ObjectId.Empty))
            {
                var brandCollection = database.GetCollection<BsonDocument>("brands");
                var brand = await brandCollection.Find(Builders<BsonDocument>.Filter.Eq("_id", brandId)).FirstOrDefaultAsync();
                return brand?["name"]?.ToString();
            }
            return null;
        }
        private void be_Click(object sender, EventArgs e)
        {
            Mainmenu mainMenu = new Mainmenu();
            mainMenu.Show();
            this.Close();
        }

        private void bae_Click(object sender, EventArgs e)
        {
            ProductsAdd addForm = new ProductsAdd();
            addForm.DataUpdated += LoadData;
            addForm.Show();
        }

        private void bde_Click(object sender, EventArgs e)
        {
            ProductsDelete deleteForm = new ProductsDelete();
            deleteForm.DataUpdated += LoadData;
            deleteForm.Show();
        }

        private void bk_Click(object sender, EventArgs e)
        {
            ProductsCategory categoryForm = new ProductsCategory();
            categoryForm.Show();

        }

        private void bb_Click(object sender, EventArgs e)
        {
            ProductsBrand brandForm = new ProductsBrand();
            brandForm.Show();
        }

        private void bz_Click(object sender, EventArgs e)
        {
            ProductsZal stockForm = new ProductsZal();
            stockForm.DataUpdated += LoadData;
            stockForm.Show();
        }
    }
}
