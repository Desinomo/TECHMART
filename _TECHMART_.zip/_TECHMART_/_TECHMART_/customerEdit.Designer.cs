﻿namespace _TECHMART_
{
    partial class customerEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            txe = new TextBox();
            label4 = new Label();
            txl = new TextBox();
            label3 = new Label();
            bk = new Button();
            txf = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(22, 72);
            label2.Name = "label2";
            label2.Size = new Size(47, 23);
            label2.TabIndex = 19;
            label2.Text = "Ім'я";
            // 
            // txe
            // 
            txe.BackColor = Color.Azure;
            txe.Cursor = Cursors.IBeam;
            txe.Location = new Point(146, 172);
            txe.Multiline = true;
            txe.Name = "txe";
            txe.Size = new Size(177, 26);
            txe.TabIndex = 18;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(22, 175);
            label4.Name = "label4";
            label4.Size = new Size(66, 23);
            label4.TabIndex = 17;
            label4.Text = "Email";
            // 
            // txl
            // 
            txl.BackColor = Color.Azure;
            txl.Cursor = Cursors.IBeam;
            txl.Location = new Point(146, 121);
            txl.Multiline = true;
            txl.Name = "txl";
            txl.Size = new Size(177, 26);
            txl.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(22, 121);
            label3.Name = "label3";
            label3.Size = new Size(109, 23);
            label3.TabIndex = 15;
            label3.Text = "Прізвище";
            // 
            // bk
            // 
            bk.BackColor = Color.Azure;
            bk.Cursor = Cursors.Hand;
            bk.FlatStyle = FlatStyle.Popup;
            bk.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bk.Location = new Point(82, 226);
            bk.Name = "bk";
            bk.Size = new Size(179, 40);
            bk.TabIndex = 14;
            bk.Text = "Відредагувати";
            bk.UseVisualStyleBackColor = false;
            bk.Click += bk_Click_1;
            // 
            // txf
            // 
            txf.BackColor = Color.Azure;
            txf.Cursor = Cursors.IBeam;
            txf.Location = new Point(146, 72);
            txf.Multiline = true;
            txf.Name = "txf";
            txf.Size = new Size(177, 26);
            txf.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(39, 17);
            label1.Name = "label1";
            label1.Size = new Size(282, 28);
            label1.TabIndex = 12;
            label1.Text = "Редагування клієнта:";
            // 
            // customerEdit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(339, 290);
            Controls.Add(label2);
            Controls.Add(txe);
            Controls.Add(label4);
            Controls.Add(txl);
            Controls.Add(label3);
            Controls.Add(bk);
            Controls.Add(txf);
            Controls.Add(label1);
            Name = "customerEdit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private TextBox txe;
        private Label label4;
        private TextBox txl;
        private Label label3;
        private Button bk;
        private TextBox txf;
        private Label label1;
    }
}