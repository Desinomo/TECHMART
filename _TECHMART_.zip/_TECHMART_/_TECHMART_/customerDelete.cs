﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class customerDelete : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;

        public customerDelete()
        {
            InitializeComponent();
            InitializeMongoDB();
        }

        private void InitializeMongoDB()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка підключення до MongoDB: {ex.Message}");
            }
        }
        private async void btod_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txf.Text) || string.IsNullOrEmpty(txl.Text) || string.IsNullOrEmpty(txe.Text))
                {
                    MessageBox.Show("Будь ласка, заповніть всі поля.");
                    return;
                }

                var customersCollection = database.GetCollection<BsonDocument>("Customers");
                var ordersCollection = database.GetCollection<BsonDocument>("Orders");
                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");

                // Знаходимо клієнта за ім'ям, прізвищем і email
                var filterCustomer = Builders<BsonDocument>.Filter.Eq("first_name", txf.Text) &
                                     Builders<BsonDocument>.Filter.Eq("last_name", txl.Text) &
                                     Builders<BsonDocument>.Filter.Eq("email", txe.Text);

                var customer = await customersCollection.Find(filterCustomer).FirstOrDefaultAsync();

                if (customer == null)
                {
                    MessageBox.Show("Клієнта не знайдено.");
                    return;
                }

                // Перевіряємо, чи є у клієнта замовлення
                var customerOrders = await ordersCollection.Find(Builders<BsonDocument>.Filter.Eq("customer_id", customer["_id"].ToString())).ToListAsync();

                if (customerOrders.Count > 0)
                {
                    var result = MessageBox.Show("У цього клієнта є замовлення. Ви впевнені, що хочете видалити цього клієнта разом з його замовленнями?", "Попередження", MessageBoxButtons.YesNo);
                    if (result == DialogResult.No)
                    {
                        return;
                    }

                    // Якщо так, видаляємо всі замовлення цього клієнта та деталі замовлення
                    foreach (var order in customerOrders)
                    {
                        var orderId = order["order_id"].ToString();
                        var filterOrderDetails = Builders<BsonDocument>.Filter.Eq("order_id", orderId);
                        await orderDetailsCollection.DeleteManyAsync(filterOrderDetails); // Видаляємо деталі замовлення

                        await ordersCollection.DeleteOneAsync(Builders<BsonDocument>.Filter.Eq("order_id", orderId)); // Видаляємо замовлення
                    }

                    MessageBox.Show("Замовлення клієнта успішно видалені.");
                }

                // Тепер видаляємо самого клієнта
                var resultDeleteCustomer = await customersCollection.DeleteOneAsync(filterCustomer);

                if (resultDeleteCustomer.DeletedCount > 0)
                {
                    MessageBox.Show("Клієнт успішно видалений.");
                }
                else
                {
                    MessageBox.Show("Клієнта не знайдено.");
                }

                txf.Clear();
                txl.Clear();
                txe.Clear();

                DataUpdated?.Invoke();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при видаленні клієнта: {ex.Message}");
            }
        }

    }
}


