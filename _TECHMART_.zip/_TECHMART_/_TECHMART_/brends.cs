﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class brends : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public brends()
        {
            InitializeComponent();
            LoadData();
            LoadCategoryData();
        }
        private async void LoadData()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");
                var collection = database.GetCollection<BsonDocument>("brands");

                var brands = await collection.Find(new BsonDocument()).ToListAsync();

                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("Brand Name");
                dataTable.Columns.Add("Description");
                foreach (var brand in brands)
                {
                    DataRow row = dataTable.NewRow();
                    row["Brand Name"] = brand["name"].ToString();
                    row["Description"] = brand["description"].ToString();
                    dataTable.Rows.Add(row);
                }

                dtgb.DataSource = dataTable;
                dtgb.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dtgb.Columns["Brand Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dtgb.Columns["Description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні даних: " + ex.Message);
            }
        }
        private async void LoadCategoryData()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");
                var categoryCollection = database.GetCollection<BsonDocument>("Categories");

                var categories = await categoryCollection.Find(new BsonDocument()).ToListAsync();

                DataTable categoryTable = new DataTable();
                categoryTable.Columns.Add("Category Name");
                foreach (var category in categories)
                {
                    DataRow row = categoryTable.NewRow();
                    row["Category Name"] = category["name"].ToString();
                    categoryTable.Rows.Add(row);
                }

                dtgc.DataSource = categoryTable;
                dtgc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dtgc.Columns["Category Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні даних категорій: " + ex.Message);
            }
        }


        private void ba_Click(object sender, EventArgs e)
        {
            breandadd brenadadd = new breandadd();
            brenadadd.DataUpdated += LoadData;
            brenadadd.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            breanddelete breanddelete = new breanddelete();
            breanddelete.DataUpdated += LoadData;
            breanddelete.Show();
        }

        private void be_Click(object sender, EventArgs e)
        {
            Mainmenu mainMenu = new Mainmenu();
            mainMenu.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            categoryadd categoryaddForm = new categoryadd();
            categoryaddForm.DataUpdated += LoadCategoryData;
            categoryaddForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            categorydelete categorydeleteForm = new categorydelete();
            categorydeleteForm.DataUpdated += LoadCategoryData;
            categorydeleteForm.Show();
        }
    }
}
