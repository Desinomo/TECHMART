﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ProductsBrand : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        private IMongoCollection<BsonDocument> brandsCollection;
        private IMongoCollection<BsonDocument> productsCollection;
        private IMongoCollection<BsonDocument> categoriesCollection;

        public ProductsBrand()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadBrands();
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");

                brandsCollection = database.GetCollection<BsonDocument>("brands");
                productsCollection = database.GetCollection<BsonDocument>("products");
                categoriesCollection = database.GetCollection<BsonDocument>("Categories");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private async void LoadBrands()
        {
            try
            {
                var brands = await brandsCollection.Find(new BsonDocument()).ToListAsync();
                DataTable brandTable = new DataTable();
                brandTable.Columns.Add("brand_id", typeof(string));
                brandTable.Columns.Add("name", typeof(string));

                foreach (var brand in brands)
                {
                    var brandId = brand["_id"].AsObjectId;
                    var brandName = brand["name"].ToString();
                    brandTable.Rows.Add(brandId, brandName);
                }

                cb.DataSource = brandTable;
                cb.DisplayMember = "name";
                cb.ValueMember = "brand_id";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка завантаження брендів: " + ex.Message);
            }
        }

        private async void bc_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedBrandId = cb.SelectedValue.ToString();
                var filter = Builders<BsonDocument>.Filter.Eq("brand_id", selectedBrandId);
                var filteredProducts = await productsCollection.Find(filter).ToListAsync();

                DataTable productTable = new DataTable();
                productTable.Columns.Add("name", typeof(string));
                productTable.Columns.Add("price", typeof(decimal));
                productTable.Columns.Add("quantity", typeof(int));
                productTable.Columns.Add("category", typeof(string));

                foreach (var product in filteredProducts)
                {
                    var productName = product["name"].ToString();
                    var productPrice = product["price"].ToDecimal();
                    var productQuantity = product["quantity"].ToInt32();
                    var categoryId = product["category_id"].ToString();

                    var categoryObjectId = ObjectId.TryParse(categoryId, out var parsedCategoryId) ? parsedCategoryId : ObjectId.Empty;
                    var categoryName = await GetCategoryName(categoryObjectId);

                    productTable.Rows.Add(productName, productPrice, productQuantity, categoryName ?? "Не вказано");
                }

                dtc.DataSource = productTable;
                dtc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (dtc.Columns.Contains("product_id"))
                {
                    dtc.Columns["product_id"].Visible = false;
                }

                var selectedBrandName = cb.Text;
                l.Text = selectedBrandName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні продуктів: " + ex.Message);
            }
        }

        private async Task<string> GetCategoryName(ObjectId categoryId)
        {
            if (!categoryId.Equals(ObjectId.Empty))
            {
                var category = await categoriesCollection.Find(Builders<BsonDocument>.Filter.Eq("_id", categoryId)).FirstOrDefaultAsync();
                return category?["name"]?.ToString();
            }
            return null;
        }

        private void be_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}