﻿namespace _TECHMART_
{
    partial class ProductsBrand
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            cb = new ComboBox();
            bc = new Button();
            be = new Button();
            l = new Label();
            dtc = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dtc).BeginInit();
            SuspendLayout();
            // 
            // cb
            // 
            cb.BackColor = Color.Azure;
            cb.Cursor = Cursors.Hand;
            cb.FormattingEnabled = true;
            cb.Location = new Point(529, 63);
            cb.Name = "cb";
            cb.Size = new Size(150, 23);
            cb.TabIndex = 33;
            // 
            // bc
            // 
            bc.BackColor = Color.Azure;
            bc.Cursor = Cursors.Hand;
            bc.FlatAppearance.BorderColor = Color.Black;
            bc.FlatStyle = FlatStyle.Popup;
            bc.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bc.Location = new Point(529, 284);
            bc.Name = "bc";
            bc.Size = new Size(150, 33);
            bc.TabIndex = 32;
            bc.Text = "Відсортувати";
            bc.UseVisualStyleBackColor = false;
            bc.Click += bc_Click;
            // 
            // be
            // 
            be.BackColor = Color.Azure;
            be.Cursor = Cursors.Hand;
            be.FlatStyle = FlatStyle.Popup;
            be.Font = new Font("Bookman Old Style", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            be.Location = new Point(12, 20);
            be.Name = "be";
            be.Size = new Size(29, 22);
            be.TabIndex = 31;
            be.Text = "<-";
            be.UseVisualStyleBackColor = false;
            be.Click += be_Click;
            // 
            // l
            // 
            l.AutoSize = true;
            l.Font = new Font("Lucida Sans Unicode", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            l.Location = new Point(395, 31);
            l.Name = "l";
            l.Size = new Size(118, 20);
            l.TabIndex = 30;
            l.Text = "Електроніка";
            // 
            // dtc
            // 
            dtc.BackgroundColor = Color.Azure;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Azure;
            dataGridViewCellStyle1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dtc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dtc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Azure;
            dataGridViewCellStyle2.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dtc.DefaultCellStyle = dataGridViewCellStyle2;
            dtc.GridColor = SystemColors.ActiveCaptionText;
            dtc.ImeMode = ImeMode.NoControl;
            dtc.Location = new Point(12, 54);
            dtc.MultiSelect = false;
            dtc.Name = "dtc";
            dtc.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.Azure;
            dataGridViewCellStyle3.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dtc.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dtc.RowHeadersVisible = false;
            dtc.RowTemplate.DefaultCellStyle.BackColor = Color.Azure;
            dtc.RowTemplate.DefaultCellStyle.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtc.Size = new Size(501, 263);
            dtc.StandardTab = true;
            dtc.TabIndex = 29;
            dtc.UseWaitCursor = true;
            // 
            // ProductsBrand
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(690, 333);
            Controls.Add(cb);
            Controls.Add(bc);
            Controls.Add(be);
            Controls.Add(l);
            Controls.Add(dtc);
            Name = "ProductsBrand";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)dtc).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cb;
        private Button bc;
        private Button be;
        private Label l;
        private DataGridView dtc;
    }
}