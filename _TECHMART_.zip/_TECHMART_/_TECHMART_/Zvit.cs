﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class Zvit : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public Zvit()
        {
            InitializeComponent();
            InitializeDatabase();
        }
        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }
        private async void b_Click_1(object sender, EventArgs e)
        {
            DateTime startDate = d1.Value.Date;
            DateTime endDate = d2.Value.Date;

            if (startDate > endDate)
            {
                MessageBox.Show("Кінцева дата повинна бути пізніше початкової.");
                return;
            }
            try
            {
                var ordersCollection = database.GetCollection<BsonDocument>("Orders");
                var customersCollection = database.GetCollection<BsonDocument>("Customers");
                var productsCollection = database.GetCollection<BsonDocument>("products");
                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");

                //Фільтр для вибору замовлень у діапазоні дат
                var filter = Builders<BsonDocument>.Filter.Gte("date", startDate) &
                         Builders<BsonDocument>.Filter.Lte("date", endDate);

                var orders = await ordersCollection.Find(filter).ToListAsync();

                DataTable dt = new DataTable();
                dt.Columns.Add("OrderNumber", typeof(int));   // Номер замовлення
                dt.Columns.Add("CustomerName", typeof(string));  // Ім'я клієнта
                dt.Columns.Add("ProductName", typeof(string));   // Назва продукту
                dt.Columns.Add("Quantity", typeof(int));         // Кількість
                dt.Columns.Add("OrderDate", typeof(DateTime));   // Дата замовлення
                dt.Columns.Add("Completezam", typeof(string));   // Статус замовлення

                foreach (var order in orders)
                {
                    string orderId = order["order_id"].ToString();
                    DateTime orderDate = order["date"].ToLocalTime();

                    var customerIdValue = order["customer_id"];
                    ObjectId customerId = ObjectId.Empty;
                    string customerName = "Невідомо";

                    if (customerIdValue.IsObjectId)
                    {
                        customerId = customerIdValue.AsObjectId;
                    }
                    else if (customerIdValue.IsString)
                    {
                        customerId = ObjectId.TryParse(customerIdValue.AsString, out var parsedCustomerId) ? parsedCustomerId : ObjectId.Empty;
                    }

                    if (!customerId.Equals(ObjectId.Empty))
                    {
                        // Завантаження Інформації про клієнта
                        var customer = await customersCollection.Find(Builders<BsonDocument>.Filter.Eq("_id", customerId)).FirstOrDefaultAsync();
                        customerName = customer?["first_name"]?.ToString() + " " + customer?["last_name"]?.ToString() ?? "Невідомо";
                    }

                    var orderDetails = await orderDetailsCollection.Find(Builders<BsonDocument>.Filter.Eq("order_id", orderId)).ToListAsync();

                    foreach (var orderDetail in orderDetails)
                    {
                        string productIdStr = orderDetail["product_id"].ToString();
                        ObjectId productId = ObjectId.TryParse(productIdStr, out var parsedProductId) ? parsedProductId : ObjectId.Empty;

                        var product = await productsCollection.Find(new BsonDocument { { "_id", productId } }).FirstOrDefaultAsync();
                        string productName = product?["name"]?.ToString() ?? "Невідомо";

                        int quantity = orderDetail["quantity"].ToInt32();
                        string completezam = orderDetail["completezam"]?.ToString() ?? "false";

                        string completezamStatus = completezam == "true" ? "так" : "ні";

                        if (cb.Checked)
                        {
                            int orderNumber = int.TryParse(orderId, out var num) ? num : 0;
                            dt.Rows.Add(orderNumber, customerName, productName, quantity, orderDate, completezamStatus);
                        }
                        else if (!cb.Checked && completezam == "true")
                        {
                            int orderNumber = int.TryParse(orderId, out var num) ? num : 0;
                            dt.Rows.Add(orderNumber, customerName, productName, quantity, orderDate, completezamStatus);
                        }
                    }
                }

                DataView view = dt.DefaultView;
                view.Sort = "OrderNumber ASC";

                if (dt.Rows.Count > 0)
                {
                    dtk.DataSource = view.ToTable();
                    dtk.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                else
                {
                    MessageBox.Show("Не знайдено замовлень у вибраному діапазоні дат.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при формуванні звіту: " + ex.Message);
            }
        }

        private void be_Click(object sender, EventArgs e)
        {
            Mainmenu mainMenu = new Mainmenu();
            mainMenu.Show();
            this.Close();
        }
        private async void dtk_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    string orderId = dtk.Rows[e.RowIndex].Cells["OrderNumber"].Value.ToString();

                    var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");
                    var productsCollection = database.GetCollection<BsonDocument>("products");

                    var filter = Builders<BsonDocument>.Filter.Eq("order_id", orderId);
                    var orderDetails = await orderDetailsCollection.Find(filter).ToListAsync();

                    decimal totalPrice = 0;
                    string message = $"Номер замовлення: {orderId}\n\n";

                    foreach (var orderDetail in orderDetails)
                    {
                        var productIdStr = orderDetail["product_id"].ToString();
                        ObjectId productId = ObjectId.TryParse(productIdStr, out var parsedProductId) ? parsedProductId : ObjectId.Empty;

                        var product = await productsCollection.Find(new BsonDocument { { "_id", productId } }).FirstOrDefaultAsync();

                        if (product != null)
                        {
                            string productName = product["name"].ToString();
                            decimal productPrice = product["price"].ToDecimal();
                            int quantity = orderDetail["quantity"].ToInt32();
                            decimal itemTotal = productPrice * quantity;

                            message += $"{productName} - {quantity} шт. x {productPrice} грн = {itemTotal} грн\n";
                            totalPrice += itemTotal;
                        }
                    }

                    message += $"\nЗагальна вартість: {totalPrice} грн";

                    MessageBox.Show(message, "Інформація про замовлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при обчисленні вартості замовлення: " + ex.Message);
            }
        }

    }
}
