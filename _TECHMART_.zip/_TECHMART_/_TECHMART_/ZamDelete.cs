﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ZamDelete : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;

        public ZamDelete()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadProducts();
            rb.CheckedChanged += Rb_CheckedChanged;
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private async void LoadProducts()
        {
            var productsCollection = database.GetCollection<BsonDocument>("products");
            var products = await productsCollection.Find(new BsonDocument()).ToListAsync();

            DataTable productTable = new DataTable();
            productTable.Columns.Add("product_id", typeof(string));
            productTable.Columns.Add("name", typeof(string));

            foreach (var product in products)
            {
                var productId = product["_id"].ToString();
                var productName = product.GetValue("name", "").ToString();
                productTable.Rows.Add(productId, productName);
            }

            cp.DataSource = productTable;
            cp.DisplayMember = "name";
            cp.ValueMember = "product_id";
        }

        private void Rb_CheckedChanged(object sender, EventArgs e)
        {
            if (rb.Checked)
            {
                label4.Visible = false;
                cp.Visible = false;
            }
            else
            {
                label4.Visible = true;
                cp.Visible = true;
            }
        }

        private async void ba_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txn.Text))
                {
                    MessageBox.Show("Будь ласка, введіть номер замовлення.");
                    return;
                }

                var ordersCollection = database.GetCollection<BsonDocument>("Orders");
                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");
                var productsCollection = database.GetCollection<BsonDocument>("products");

                var filterOrder = Builders<BsonDocument>.Filter.Eq("order_id", txn.Text);
                var order = await ordersCollection.Find(filterOrder).FirstOrDefaultAsync();

                if (order == null)
                {
                    MessageBox.Show("Замовлення не знайдено.");
                    return;
                }

                FilterDefinition<BsonDocument> filterOrderDetails;
                if (rb.Checked)
                {
                    filterOrderDetails = Builders<BsonDocument>.Filter.Eq("order_id", txn.Text);
                }
                else
                {
                    var selectedProductId = cp.SelectedValue.ToString();
                    filterOrderDetails = Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("order_id", txn.Text),
                        Builders<BsonDocument>.Filter.Eq("product_id", selectedProductId)
                    );
                }

                var selectedOrderDetails = await orderDetailsCollection.Find(filterOrderDetails).ToListAsync();

                if (selectedOrderDetails.Count == 0)
                {
                    MessageBox.Show("Не знайдено замовлення для видалення.");
                    return;
                }

                foreach (var orderDetail in selectedOrderDetails)
                {
                    var productId = orderDetail["product_id"].ToString();
                    var quantity = Convert.ToInt32(orderDetail["quantity"]);

                    var productFilter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(productId));
                    var product = await productsCollection.Find(productFilter).FirstOrDefaultAsync();

                    if (product != null)
                    {
                        var currentQuantity = Convert.ToInt32(product["quantity"]);
                        var updatedQuantity = currentQuantity + quantity;

                        var update = Builders<BsonDocument>.Update.Set("quantity", updatedQuantity);
                        await productsCollection.UpdateOneAsync(productFilter, update);
                    }
                }

                await orderDetailsCollection.DeleteManyAsync(filterOrderDetails);
                MessageBox.Show("Продукти з замовлення успішно видалено.");


                var remainingOrderDetails = await orderDetailsCollection.Find(Builders<BsonDocument>.Filter.Eq("order_id", txn.Text)).ToListAsync();
                bool isOnlyOneProductLeft = remainingOrderDetails.Count == 0;


                if (isOnlyOneProductLeft || rb.Checked)
                {
                    await ordersCollection.DeleteOneAsync(filterOrder);
                    MessageBox.Show("Замовлення успішно видалено.");
                }

                DataUpdated?.Invoke();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при видаленні замовлення: " + ex.Message);
            }
        }


        private void label4_Click_1(object sender, EventArgs e)
        {

        }
    }
}
