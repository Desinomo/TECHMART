﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ZamComplete : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;
        public ZamComplete()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadOrderNumbers();
        }
        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }
        private async void LoadOrderNumbers()
        {
            try
            {
                var ordersCollection = database.GetCollection<BsonDocument>("Orders");
                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");

                var filter = Builders<BsonDocument>.Filter.Eq("completezam", false);

                var orders = await orderDetailsCollection.Find(filter).ToListAsync();

                foreach (var orderDetail in orders)
                {
                    string orderNumber = orderDetail["order_id"].ToString();
                    if (!cp.Items.Contains(orderNumber))
                    {
                        cp.Items.Add(orderNumber);
                    }
                }

                if (cp.Items.Count > 0)
                {
                    cp.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні номерів замовлень: " + ex.Message);
            }
        }
        private async void ba_Click(object sender, EventArgs e)
        {
            string selectedOrderNumber = cp.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedOrderNumber))
            {
                MessageBox.Show("Будь ласка, виберіть номер замовлення.");
                return;
            }

            try
            {
                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");

                var filter = Builders<BsonDocument>.Filter.Eq("order_id", selectedOrderNumber);
                var update = Builders<BsonDocument>.Update.Set("completezam", true);

                var result = await orderDetailsCollection.UpdateManyAsync(filter, update);

                if (result.ModifiedCount > 0)
                {
                    MessageBox.Show("Статус замовлення оновлено успішно!");
                }
                else
                {
                    MessageBox.Show("Не вдалося оновити статус для цього замовлення.");
                }
                DataUpdated?.Invoke();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при оновленні статусу: " + ex.Message);
            }
        }
    }
}
