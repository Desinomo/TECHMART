﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ZamSearch : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;

        public ZamSearch()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadComboBox();
            if (cc.SelectedItem.ToString() == "Ім'яКлієнта")
            {
                tx2.Visible = true;
                tx3.Visible = true;
                l2.Visible = true;
                l3.Visible = true; 
            }
            else
            {
                tx2.Visible = false;
                tx3.Visible = false;
                l2.Visible = false;
                l3.Visible = false;
            }
            cc.SelectedIndexChanged += new EventHandler(cc_SelectedIndexChanged);
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);
                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private void LoadComboBox()
        {
            cc.Items.Add("НомерЗамовлення");
            cc.Items.Add("Ім'яКлієнта");
            cc.Items.Add("НазваПродукту");
            cc.SelectedIndex = 0;
        }

        private void cc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cc.SelectedItem.ToString() == "Ім'яКлієнта")
            {
                tx2.Visible = true;
                tx3.Visible = true;
                l2.Visible = true; 
                l3.Visible = true;
            }
            else
            {
                tx2.Visible = false;
                tx3.Visible = false;
                l2.Visible = false;
                l3.Visible = false;
            }
        }


        private async void ba_Click(object sender, EventArgs e)
        {
            string searchText = txn.Text.Trim();  // Отримуємо текст для пошуку
            string lastName = tx2.Text.Trim();    // Прізвище для пошуку
            string email = tx3.Text.Trim();       // Емейл для пошуку

            if (string.IsNullOrEmpty(searchText) && string.IsNullOrEmpty(lastName) && string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Будь ласка, введіть хоча б один критерій для пошуку.");
                return;
            }

            try
            {
                var ordersCollection = database.GetCollection<BsonDocument>("Orders");
                var customersCollection = database.GetCollection<BsonDocument>("Customers");
                var productsCollection = database.GetCollection<BsonDocument>("products");
                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");

                DataTable dt = new DataTable();
                dt.Columns.Add("OrderNumber", typeof(string));   // Номер замовлення
                dt.Columns.Add("CustomerName", typeof(string));  // Ім'я клієнта
                dt.Columns.Add("ProductName", typeof(string));   // Назва продукту
                dt.Columns.Add("Quantity", typeof(int));         // Кількість
                dt.Columns.Add("OrderDate", typeof(DateTime));   // Дата замовлення
                dt.Columns.Add("CompleteZam", typeof(string));   // Стовпець "Виконано"

                bool? isCompleteZam = cb.Checked ? (bool?)null : (bool?)false;

                if (cc.SelectedItem.ToString() == "НомерЗамовлення")
                {
                    var filter = Builders<BsonDocument>.Filter.Eq("order_id", searchText);
                    var orders = await ordersCollection.Find(filter).SortBy(o => o["order_id"]).ToListAsync();

                    foreach (var order in orders)
                    {
                        await ProcessOrder(order, dt, orderDetailsCollection, productsCollection, customersCollection, isCompleteZam);
                    }
                }
                else if (cc.SelectedItem.ToString() == "Ім'яКлієнта")
                {
                    var filterBuilder = Builders<BsonDocument>.Filter;
                    var filters = new List<FilterDefinition<BsonDocument>>();

                    filters.Add(filterBuilder.Eq("first_name", searchText));

                    if (!string.IsNullOrEmpty(lastName))
                        filters.Add(filterBuilder.Eq("last_name", lastName));

                    if (!string.IsNullOrEmpty(email))
                        filters.Add(filterBuilder.Eq("email", email));

                    var customerFilter = filterBuilder.And(filters);

                    var customers = await customersCollection.Find(customerFilter).ToListAsync();

                    if (customers.Any())
                    {
                        foreach (var customer in customers)
                        {
                            string customerId = customer["_id"].ToString();
                            var orderFilter = Builders<BsonDocument>.Filter.Eq("customer_id", customerId);
                            var orders = await ordersCollection.Find(orderFilter).SortBy(o => o["order_id"]).ToListAsync();

                            foreach (var order in orders)
                            {
                                await ProcessOrder(order, dt, orderDetailsCollection, productsCollection, customersCollection, isCompleteZam);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Клієнта з таким іменем не знайдено.");
                        return;
                    }
                }
                else if (cc.SelectedItem.ToString() == "НазваПродукту")
                {
                    var productFilter = Builders<BsonDocument>.Filter.Eq("name", searchText);
                    var product = await productsCollection.Find(productFilter).FirstOrDefaultAsync();

                    if (product != null)
                    {
                        string productId = product["_id"].ToString();
                        var orderDetailsFilter = Builders<BsonDocument>.Filter.Eq("product_id", productId);

                        var orderDetails = await orderDetailsCollection.Find(orderDetailsFilter).ToListAsync();

                        HashSet<string> processedOrderIds = new HashSet<string>();

                        foreach (var orderDetail in orderDetails)
                        {
                            var orderId = orderDetail["order_id"].ToString();

                            if (!processedOrderIds.Contains(orderId))
                            {
                                processedOrderIds.Add(orderId);

                                var orderFilter = Builders<BsonDocument>.Filter.Eq("order_id", orderId);
                                var orders = await ordersCollection.Find(orderFilter).SortBy(o => o["order_id"]).ToListAsync();

                                foreach (var order in orders)
                                {
                                    await ProcessOrder(order, dt, orderDetailsCollection, productsCollection, customersCollection, isCompleteZam);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Продукту з таким ім'ям не знайдено.");
                        return;
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    dtz.DataSource = dt;
                    dtz.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                else
                {
                    MessageBox.Show("Не знайдено замовлень за вашим запитом.");
                }

                DataUpdated?.Invoke();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при пошуку: " + ex.Message);
            }
        }

        private async Task ProcessOrder(BsonDocument order, DataTable dt, IMongoCollection<BsonDocument> orderDetailsCollection, IMongoCollection<BsonDocument> productsCollection, IMongoCollection<BsonDocument> customersCollection, bool? isCompleteZam)
        {
            string orderId = order["order_id"].ToString();
            string customerName = await GetCustomerName(order["customer_id"].ToString(), customersCollection);
            DateTime orderDate = order["date"].ToLocalTime();

            var orderDetailsFilter = Builders<BsonDocument>.Filter.Eq("order_id", orderId);

            if (isCompleteZam.HasValue)
            {
                orderDetailsFilter &= Builders<BsonDocument>.Filter.Eq("completezam", isCompleteZam.Value);
            }

            var orderDetails = await orderDetailsCollection.Find(orderDetailsFilter).ToListAsync();

            foreach (var orderDetail in orderDetails)
            {
                string productIdStr = orderDetail["product_id"].ToString();
                ObjectId productId = ObjectId.TryParse(productIdStr, out var parsedProductId) ? parsedProductId : ObjectId.Empty;

                var product = await productsCollection.Find(new BsonDocument { { "_id", productId } }).FirstOrDefaultAsync();
                string productName = product?["name"]?.ToString() ?? "Невідомо";
                int quantity = orderDetail["quantity"].ToInt32();

                bool completeZam = orderDetail["completezam"].ToBoolean();

                dt.Rows.Add(orderId, customerName, productName, quantity, orderDate, completeZam ? "Так" : "Ні");
            }
        }

        private async Task<string> GetCustomerName(string customerId, IMongoCollection<BsonDocument> customersCollection)
        {
            var customer = await customersCollection.Find(Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(customerId))).FirstOrDefaultAsync();
            return customer != null ? $"{customer["first_name"]} {customer["last_name"]}" : "Невідомо";
        }
    


        private void be_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
