﻿namespace _TECHMART_
{
    partial class breandadd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txnb = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txob = new TextBox();
            btod = new Button();
            SuspendLayout();
            // 
            // txnb
            // 
            txnb.BackColor = Color.Azure;
            txnb.Cursor = Cursors.IBeam;
            txnb.Location = new Point(96, 68);
            txnb.Multiline = true;
            txnb.Name = "txnb";
            txnb.Size = new Size(177, 26);
            txnb.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(261, 28);
            label1.TabIndex = 1;
            label1.Text = "Додавання бренду:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(12, 69);
            label2.Name = "label2";
            label2.Size = new Size(77, 23);
            label2.TabIndex = 2;
            label2.Text = "Назва:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(12, 115);
            label3.Name = "label3";
            label3.Size = new Size(70, 23);
            label3.TabIndex = 3;
            label3.Text = "Опис:";
            // 
            // txob
            // 
            txob.BackColor = Color.Azure;
            txob.Cursor = Cursors.IBeam;
            txob.Location = new Point(96, 121);
            txob.Multiline = true;
            txob.Name = "txob";
            txob.Size = new Size(177, 120);
            txob.TabIndex = 4;
            txob.TextChanged += txob_TextChanged;
            // 
            // btod
            // 
            btod.BackColor = Color.Azure;
            btod.Cursor = Cursors.Hand;
            btod.FlatStyle = FlatStyle.Popup;
            btod.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btod.Location = new Point(51, 260);
            btod.Name = "btod";
            btod.Size = new Size(179, 40);
            btod.TabIndex = 5;
            btod.Text = "Створити";
            btod.UseVisualStyleBackColor = false;
            btod.Click += btod_Click;
            // 
            // breandadd
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(276, 312);
            Controls.Add(btod);
            Controls.Add(txob);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txnb);
            Name = "breandadd";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txnb;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txob;
        private Button btod;
    }
}