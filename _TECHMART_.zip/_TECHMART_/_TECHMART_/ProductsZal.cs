﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ProductsZal : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        private IMongoCollection<BsonDocument> productsCollection;
        public event Action DataUpdated;
        public ProductsZal()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadProducts();
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");
                productsCollection = database.GetCollection<BsonDocument>("products");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private async void LoadProducts()
        {
            try
            {
                var products = await productsCollection.Find(new BsonDocument()).ToListAsync();

                if (products == null || products.Count == 0)
                {
                    MessageBox.Show("Немає продуктів для відображення.");
                    return;
                }

                DataTable productTable = new DataTable();
                productTable.Columns.Add("product_id", typeof(string));
                productTable.Columns.Add("name", typeof(string));

                foreach (var product in products)
                {
                    var productId = product["_id"].ToString(); 
                    var productName = product["name"]?.ToString();
                    if (!string.IsNullOrEmpty(productName))
                    {
                        productTable.Rows.Add(productId, productName);
                    }
                }

                cz.DataSource = productTable;
                cz.DisplayMember = "name";
                cz.ValueMember = "product_id";
                cz.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка завантаження продуктів: " + ex.Message);
            }
        }


        private async void bz_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (cz.SelectedValue == null || string.IsNullOrWhiteSpace(txz.Text))
                {
                    MessageBox.Show("Оберіть продукт та введіть кількість.");
                    return;
                }

                var selectedProductId = cz.SelectedValue.ToString();
                if (!int.TryParse(txz.Text, out int newQuantity) || newQuantity < 0)
                {
                    MessageBox.Show("Введіть коректне число.");
                    return;
                }

                var filter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(selectedProductId));
                var update = Builders<BsonDocument>.Update.Set("quantity", newQuantity);
                var result = await productsCollection.UpdateOneAsync(filter, update);
                DataUpdated?.Invoke();
                

                if (result.ModifiedCount > 0)
                {
                    MessageBox.Show("Кількість оновлено успішно!");
                }
                else
                {
                    MessageBox.Show("Не вдалося оновити кількість. Перевірте вибір продукту.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при оновленні кількості: " + ex.Message);
            }
            this.Close();
        }
    }
}
