﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Data;
using System.Windows.Forms;

namespace _TECHMART_
{
    public partial class ZamAdd : Form
    {
        private MongoClient mongoClient;
        private IMongoDatabase database;
        public event Action DataUpdated;

        public ZamAdd()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadClients();
            LoadProducts();
        }

        private void InitializeDatabase()
        {
            try
            {
                const string connectionUri = "mongodb+srv://Desinomo:db1@database.aiv9o.mongodb.net/?retryWrites=true&w=majority&appName=DataBase";
                var settings = MongoClientSettings.FromConnectionString(connectionUri);
                settings.ServerApi = new ServerApi(ServerApiVersion.V1);
                mongoClient = new MongoClient(settings);

                database = mongoClient.GetDatabase("_TECHMART_");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка підключення до бази даних: " + ex.Message);
            }
        }

        private async void LoadClients()
        {
            var clientsCollection = database.GetCollection<BsonDocument>("Customers");
            var clients = await clientsCollection.Find(new BsonDocument()).ToListAsync();

            DataTable clientTable = new DataTable();
            clientTable.Columns.Add("customer_id", typeof(string));
            clientTable.Columns.Add("full_name", typeof(string));

            foreach (var client in clients)
            {
                var clientId = client["_id"].ToString();
                var clientName = client.GetValue("first_name", "").ToString();
                var clientLastName = client.GetValue("last_name", "").ToString();
                var fullName = clientName + " " + clientLastName;
                clientTable.Rows.Add(clientId, fullName);
            }

            cc.DataSource = clientTable;
            cc.DisplayMember = "full_name";
            cc.ValueMember = "customer_id";
        }

        private async void LoadProducts()
        {
            var productsCollection = database.GetCollection<BsonDocument>("products");
            var products = await productsCollection.Find(new BsonDocument()).ToListAsync();

            DataTable productTable = new DataTable();
            productTable.Columns.Add("product_id", typeof(string));
            productTable.Columns.Add("name", typeof(string));

            foreach (var product in products)
            {
                var productId = product["_id"].ToString();
                var productName = product.GetValue("name", "").ToString();
                productTable.Rows.Add(productId, productName);
            }

            cp.DataSource = productTable;
            cp.DisplayMember = "name";
            cp.ValueMember = "product_id";
        }

        private async void ba_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txn.Text) || cc.SelectedValue == null || cp.SelectedValue == null || string.IsNullOrWhiteSpace(txq.Text) || d.Value == null)
                {
                    MessageBox.Show("Будь ласка, заповніть усі поля.");
                    return;
                }

                if (!int.TryParse(txq.Text, out int quantity) || quantity <= 0)
                {
                    MessageBox.Show("Введіть коректну кількість товару.");
                    return;
                }

                var ordersCollection = database.GetCollection<BsonDocument>("Orders");
                var customersCollection = database.GetCollection<BsonDocument>("Customers");
                var productsCollection = database.GetCollection<BsonDocument>("products");

                var productFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(cp.SelectedValue.ToString()));
                var product = await productsCollection.Find(productFilter).FirstOrDefaultAsync();

                if (product == null)
                {
                    MessageBox.Show("Продукт не знайдено.");
                    return;
                }

                int stockQuantity = product.GetValue("quantity", 0).ToInt32();
                if (stockQuantity < quantity)
                {
                    MessageBox.Show("Недостатньо товару на складі.");
                    return;
                }

                var filter = Builders<BsonDocument>.Filter.Eq("order_id", txn.Text);
                var existingOrder = await ordersCollection.Find(filter).FirstOrDefaultAsync();

                string customerId;
                string customerName = "Невідомий клієнт";

                decimal totalOrderPrice = 0;

                if (existingOrder != null)
                {
                    customerId = existingOrder.GetValue("customer_id", "").ToString();
                    BsonDocument customer = await customersCollection.Find(Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(customerId))).FirstOrDefaultAsync();

                    if (customer != null)
                    {
                        customerName = $"{customer.GetValue("first_name", "")} {customer.GetValue("last_name", "")}";
                    }

                    var existingOrderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");
                    var orderDetailsFilter = Builders<BsonDocument>.Filter.Eq("order_id", txn.Text);
                    var existingOrderDetails = await existingOrderDetailsCollection.Find(orderDetailsFilter).ToListAsync();

                    foreach (var orderDetail in existingOrderDetails)
                    {
                        if (orderDetail.GetValue("completezam", false).ToBoolean() == true)
                        {
                            MessageBox.Show("Замовлення з таким ID вже завершено. Не можна додавати нові товари.");
                            return;
                        }
                    }

                    var result = MessageBox.Show($"Замовлення з номером {txn.Text} вже існує!\nКлієнт: {customerName}.\nБажаєте додати товар до цього замовлення?", "Попередження", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.No)
                    {
                        return;
                    }

                    foreach (var orderDetail in existingOrderDetails)
                    {
                        var productId = orderDetail["product_id"].ToString();
                        var productFilterForCost = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(productId));
                        var productForCost = await productsCollection.Find(productFilterForCost).FirstOrDefaultAsync();

                        if (productForCost != null)
                        {
                            decimal productCostPrice = productForCost.GetValue("price", 0).ToDecimal();
                            int orderQuantity = orderDetail["quantity"].ToInt32();
                            totalOrderPrice += productCostPrice * orderQuantity;
                        }
                    }

                    var updateOrder = Builders<BsonDocument>.Update.Set("total_price", totalOrderPrice);
                    await ordersCollection.UpdateOneAsync(filter, updateOrder);
                }
                else
                {
                    customerId = cc.SelectedValue.ToString();
                    var newOrder = new BsonDocument
            {
                { "order_id", txn.Text },
                { "customer_id", customerId },
                { "date", d.Value.Date },
                { "total_price", 0 }
            };
                    await ordersCollection.InsertOneAsync(newOrder);
                }

                var orderDetails = new BsonDocument
        {
            { "order_id", txn.Text },
            { "product_id", cp.SelectedValue.ToString() },
            { "quantity", quantity },
            { "completezam", false }
        };

                var orderDetailsCollection = database.GetCollection<BsonDocument>("Order_Details");
                await orderDetailsCollection.InsertOneAsync(orderDetails);

                decimal productCostPriceForNew = product.GetValue("price", 0).ToDecimal();
                totalOrderPrice += productCostPriceForNew * quantity;

                var updateOrderTotal = Builders<BsonDocument>.Update.Set("total_price", totalOrderPrice);
                await ordersCollection.UpdateOneAsync(filter, updateOrderTotal);

                var updateProduct = Builders<BsonDocument>.Update.Inc("quantity", -quantity);
                await productsCollection.UpdateOneAsync(productFilter, updateProduct);

                MessageBox.Show("Замовлення додано успішно!");
                DataUpdated?.Invoke();
                cp.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при додаванні замовлення: " + ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}