﻿namespace _TECHMART_
{
    partial class Zvit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            b = new Button();
            be = new Button();
            dtk = new DataGridView();
            d1 = new DateTimePicker();
            d2 = new DateTimePicker();
            label2 = new Label();
            label1 = new Label();
            label4 = new Label();
            cb = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)dtk).BeginInit();
            SuspendLayout();
            // 
            // b
            // 
            b.BackColor = Color.Azure;
            b.Cursor = Cursors.Hand;
            b.FlatStyle = FlatStyle.Popup;
            b.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            b.Location = new Point(408, 399);
            b.Name = "b";
            b.Size = new Size(162, 39);
            b.TabIndex = 21;
            b.Text = "Сформувати звіт";
            b.UseVisualStyleBackColor = false;
            b.Click += b_Click_1;
            // 
            // be
            // 
            be.BackColor = Color.Azure;
            be.Cursor = Cursors.Hand;
            be.FlatStyle = FlatStyle.Popup;
            be.Font = new Font("Bookman Old Style", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            be.Location = new Point(12, 12);
            be.Name = "be";
            be.Size = new Size(29, 22);
            be.TabIndex = 22;
            be.Text = "<-";
            be.UseVisualStyleBackColor = false;
            be.Click += be_Click;
            // 
            // dtk
            // 
            dtk.BackgroundColor = Color.Azure;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Azure;
            dataGridViewCellStyle1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dtk.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dtk.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Azure;
            dataGridViewCellStyle2.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dtk.DefaultCellStyle = dataGridViewCellStyle2;
            dtk.GridColor = SystemColors.ActiveCaptionText;
            dtk.ImeMode = ImeMode.NoControl;
            dtk.Location = new Point(12, 40);
            dtk.MultiSelect = false;
            dtk.Name = "dtk";
            dtk.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.Azure;
            dataGridViewCellStyle3.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dtk.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dtk.RowHeadersVisible = false;
            dtk.RowTemplate.DefaultCellStyle.BackColor = Color.Azure;
            dtk.RowTemplate.DefaultCellStyle.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtk.Size = new Size(374, 398);
            dtk.StandardTab = true;
            dtk.TabIndex = 23;
            dtk.UseWaitCursor = true;
            dtk.CellClick += dtk_CellClick_1;
            // 
            // d1
            // 
            d1.CalendarMonthBackground = Color.Azure;
            d1.Cursor = Cursors.Hand;
            d1.Location = new Point(399, 58);
            d1.Name = "d1";
            d1.Size = new Size(171, 23);
            d1.TabIndex = 26;
            // 
            // d2
            // 
            d2.CalendarMonthBackground = Color.Azure;
            d2.Cursor = Cursors.Hand;
            d2.Location = new Point(399, 102);
            d2.Name = "d2";
            d2.Size = new Size(171, 23);
            d2.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(399, 40);
            label2.Name = "label2";
            label2.Size = new Size(105, 15);
            label2.TabIndex = 28;
            label2.Text = "Початкова дата";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(399, 84);
            label1.Name = "label1";
            label1.Size = new Size(88, 15);
            label1.TabIndex = 29;
            label1.Text = "Кінцева дата";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Bold);
            label4.Location = new Point(392, 371);
            label4.Name = "label4";
            label4.Size = new Size(193, 16);
            label4.TabIndex = 56;
            label4.Text = "не завершені замовлення";
            // 
            // cb
            // 
            cb.AutoSize = true;
            cb.Cursor = Cursors.Hand;
            cb.Font = new Font("Lucida Sans Unicode", 9.75F, FontStyle.Bold);
            cb.Location = new Point(437, 348);
            cb.Name = "cb";
            cb.Size = new Size(123, 20);
            cb.TabIndex = 55;
            cb.Text = "Відображати ";
            cb.UseVisualStyleBackColor = true;
            // 
            // Zvit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(587, 450);
            Controls.Add(label4);
            Controls.Add(cb);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(d2);
            Controls.Add(d1);
            Controls.Add(dtk);
            Controls.Add(be);
            Controls.Add(b);
            Name = "Zvit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)dtk).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button b;
        private Button be;
        private DataGridView dtk;
        private DateTimePicker d1;
        private DateTimePicker d2;
        private Label label2;
        private Label label1;
        private Label label4;
        private CheckBox cb;
    }
}