﻿namespace _TECHMART_
{
    partial class ZamSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            txn = new TextBox();
            cc = new ComboBox();
            label2 = new Label();
            label3 = new Label();
            ba = new Button();
            label1 = new Label();
            dtz = new DataGridView();
            be = new Button();
            cb = new CheckBox();
            label4 = new Label();
            tx2 = new TextBox();
            l2 = new Label();
            tx3 = new TextBox();
            l3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dtz).BeginInit();
            SuspendLayout();
            // 
            // txn
            // 
            txn.BackColor = Color.Azure;
            txn.Cursor = Cursors.IBeam;
            txn.Location = new Point(717, 134);
            txn.Multiline = true;
            txn.Name = "txn";
            txn.Size = new Size(174, 26);
            txn.TabIndex = 50;
            // 
            // cc
            // 
            cc.BackColor = Color.Azure;
            cc.Cursor = Cursors.Hand;
            cc.FormattingEnabled = true;
            cc.Location = new Point(637, 105);
            cc.Name = "cc";
            cc.Size = new Size(174, 23);
            cc.TabIndex = 46;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(582, 79);
            label2.Name = "label2";
            label2.Size = new Size(303, 23);
            label2.TabIndex = 45;
            label2.Text = "Виберіть по якому стовпцю:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(547, 137);
            label3.Name = "label3";
            label3.Size = new Size(164, 23);
            label3.TabIndex = 43;
            label3.Text = "Ключове слово";
            // 
            // ba
            // 
            ba.BackColor = Color.Azure;
            ba.Cursor = Cursors.Hand;
            ba.FlatStyle = FlatStyle.Popup;
            ba.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ba.Location = new Point(338, 398);
            ba.Name = "ba";
            ba.RightToLeft = RightToLeft.Yes;
            ba.Size = new Size(263, 40);
            ba.TabIndex = 42;
            ba.Text = "Пошук ";
            ba.UseVisualStyleBackColor = false;
            ba.Click += ba_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans Unicode", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.Location = new Point(596, 12);
            label1.Name = "label1";
            label1.Size = new Size(263, 28);
            label1.TabIndex = 41;
            label1.Text = "Пошук замовлення:";
            // 
            // dtz
            // 
            dtz.BackgroundColor = Color.Azure;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.Azure;
            dataGridViewCellStyle4.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dtz.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dtz.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.Azure;
            dataGridViewCellStyle5.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dtz.DefaultCellStyle = dataGridViewCellStyle5;
            dtz.GridColor = SystemColors.ActiveCaptionText;
            dtz.ImeMode = ImeMode.NoControl;
            dtz.Location = new Point(12, 40);
            dtz.MultiSelect = false;
            dtz.Name = "dtz";
            dtz.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.Azure;
            dataGridViewCellStyle6.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dtz.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dtz.RowHeadersVisible = false;
            dtz.RowTemplate.DefaultCellStyle.BackColor = Color.Azure;
            dtz.RowTemplate.DefaultCellStyle.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtz.Size = new Size(516, 342);
            dtz.StandardTab = true;
            dtz.TabIndex = 51;
            dtz.UseWaitCursor = true;
            // 
            // be
            // 
            be.BackColor = Color.Azure;
            be.Cursor = Cursors.Hand;
            be.FlatStyle = FlatStyle.Popup;
            be.Font = new Font("Bookman Old Style", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            be.Location = new Point(12, 12);
            be.Name = "be";
            be.Size = new Size(29, 22);
            be.TabIndex = 52;
            be.Text = "<-";
            be.UseVisualStyleBackColor = false;
            be.Click += be_Click;
            // 
            // cb
            // 
            cb.AutoSize = true;
            cb.Cursor = Cursors.Hand;
            cb.Font = new Font("Lucida Sans Unicode", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            cb.Location = new Point(628, 324);
            cb.Name = "cb";
            cb.Size = new Size(183, 29);
            cb.TabIndex = 53;
            cb.Text = "Відображати ";
            cb.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans Unicode", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(582, 356);
            label4.Name = "label4";
            label4.Size = new Size(268, 25);
            label4.TabIndex = 54;
            label4.Text = "завершені замовлення";
            // 
            // tx2
            // 
            tx2.BackColor = Color.Azure;
            tx2.Cursor = Cursors.IBeam;
            tx2.Location = new Point(662, 166);
            tx2.Multiline = true;
            tx2.Name = "tx2";
            tx2.Size = new Size(229, 26);
            tx2.TabIndex = 56;
            // 
            // l2
            // 
            l2.AutoSize = true;
            l2.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            l2.Location = new Point(547, 169);
            l2.Name = "l2";
            l2.Size = new Size(109, 23);
            l2.TabIndex = 55;
            l2.Text = "Прізвище";
            // 
            // tx3
            // 
            tx3.BackColor = Color.Azure;
            tx3.Cursor = Cursors.IBeam;
            tx3.Location = new Point(619, 198);
            tx3.Multiline = true;
            tx3.Name = "tx3";
            tx3.Size = new Size(272, 26);
            tx3.TabIndex = 58;
            // 
            // l3
            // 
            l3.AutoSize = true;
            l3.Font = new Font("Lucida Sans Unicode", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            l3.Location = new Point(547, 201);
            l3.Name = "l3";
            l3.Size = new Size(66, 23);
            l3.TabIndex = 57;
            l3.Text = "Email";
            // 
            // ZamSearch
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(926, 450);
            Controls.Add(tx3);
            Controls.Add(l3);
            Controls.Add(tx2);
            Controls.Add(l2);
            Controls.Add(label4);
            Controls.Add(cb);
            Controls.Add(be);
            Controls.Add(dtz);
            Controls.Add(txn);
            Controls.Add(cc);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(ba);
            Controls.Add(label1);
            Name = "ZamSearch";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)dtz).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txn;
        private ComboBox cc;
        private Label label2;
        private Label label3;
        private Button ba;
        private Label label1;
        private DataGridView dtz;
        private Button be;
        private CheckBox cb;
        private Label label4;
        private TextBox tx2;
        private Label l2;
        private TextBox tx3;
        private Label l3;
    }
}