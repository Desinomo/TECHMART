﻿namespace _TECHMART_
{
    partial class Products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            dte = new DataGridView();
            l = new Label();
            bde = new Button();
            bae = new Button();
            be = new Button();
            bz = new Button();
            bb = new Button();
            bk = new Button();
            ((System.ComponentModel.ISupportInitialize)dte).BeginInit();
            SuspendLayout();
            // 
            // dte
            // 
            dte.BackgroundColor = Color.Azure;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.Azure;
            dataGridViewCellStyle4.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dte.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dte.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.Azure;
            dataGridViewCellStyle5.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dte.DefaultCellStyle = dataGridViewCellStyle5;
            dte.GridColor = SystemColors.ActiveCaptionText;
            dte.ImeMode = ImeMode.NoControl;
            dte.Location = new Point(12, 46);
            dte.MultiSelect = false;
            dte.Name = "dte";
            dte.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.Azure;
            dataGridViewCellStyle6.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dte.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dte.RowHeadersVisible = false;
            dte.RowTemplate.DefaultCellStyle.BackColor = Color.Azure;
            dte.RowTemplate.DefaultCellStyle.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dte.Size = new Size(501, 392);
            dte.StandardTab = true;
            dte.TabIndex = 2;
            dte.UseWaitCursor = true;
            // 
            // l
            // 
            l.AutoSize = true;
            l.Font = new Font("Lucida Sans Unicode", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            l.Location = new Point(395, 23);
            l.Name = "l";
            l.Size = new Size(118, 20);
            l.TabIndex = 15;
            l.Text = "Електроніка";
            // 
            // bde
            // 
            bde.BackColor = Color.Azure;
            bde.Cursor = Cursors.Hand;
            bde.FlatAppearance.BorderColor = Color.Black;
            bde.FlatStyle = FlatStyle.Popup;
            bde.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bde.Location = new Point(528, 129);
            bde.Name = "bde";
            bde.Size = new Size(213, 68);
            bde.TabIndex = 16;
            bde.Text = "Видалити продукт";
            bde.UseVisualStyleBackColor = false;
            bde.Click += bde_Click;
            // 
            // bae
            // 
            bae.BackColor = Color.Azure;
            bae.Cursor = Cursors.Hand;
            bae.FlatStyle = FlatStyle.Popup;
            bae.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bae.Location = new Point(528, 46);
            bae.Name = "bae";
            bae.Size = new Size(213, 77);
            bae.TabIndex = 17;
            bae.Text = "Додати продукт";
            bae.UseVisualStyleBackColor = false;
            bae.Click += bae_Click;
            // 
            // be
            // 
            be.BackColor = Color.Azure;
            be.Cursor = Cursors.Hand;
            be.FlatStyle = FlatStyle.Popup;
            be.Font = new Font("Bookman Old Style", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            be.Location = new Point(12, 12);
            be.Name = "be";
            be.Size = new Size(29, 22);
            be.TabIndex = 18;
            be.Text = "<-";
            be.UseVisualStyleBackColor = false;
            be.Click += be_Click;
            // 
            // bz
            // 
            bz.BackColor = Color.Azure;
            bz.Cursor = Cursors.Hand;
            bz.FlatAppearance.BorderColor = Color.Black;
            bz.FlatStyle = FlatStyle.Popup;
            bz.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bz.Location = new Point(528, 367);
            bz.Name = "bz";
            bz.Size = new Size(213, 71);
            bz.TabIndex = 19;
            bz.Text = "Змінити залишок";
            bz.UseVisualStyleBackColor = false;
            bz.Click += bz_Click;
            // 
            // bb
            // 
            bb.BackColor = Color.Azure;
            bb.Cursor = Cursors.Hand;
            bb.FlatAppearance.BorderColor = Color.Black;
            bb.FlatStyle = FlatStyle.Popup;
            bb.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bb.Location = new Point(528, 285);
            bb.Name = "bb";
            bb.Size = new Size(213, 76);
            bb.TabIndex = 20;
            bb.Text = "Електроніка за брендом";
            bb.UseVisualStyleBackColor = false;
            bb.Click += bb_Click;
            // 
            // bk
            // 
            bk.BackColor = Color.Azure;
            bk.Cursor = Cursors.Hand;
            bk.FlatAppearance.BorderColor = Color.Black;
            bk.FlatStyle = FlatStyle.Popup;
            bk.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            bk.Location = new Point(528, 203);
            bk.Name = "bk";
            bk.Size = new Size(213, 76);
            bk.TabIndex = 21;
            bk.Text = "Електроніка за Категорією";
            bk.UseVisualStyleBackColor = false;
            bk.Click += bk_Click;
            // 
            // Products
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(750, 450);
            Controls.Add(bk);
            Controls.Add(bb);
            Controls.Add(bz);
            Controls.Add(be);
            Controls.Add(bae);
            Controls.Add(bde);
            Controls.Add(l);
            Controls.Add(dte);
            Name = "Products";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)dte).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dte;
        private Label l;
        private Button bde;
        private Button bae;
        private Button be;
        private Button bz;
        private Button bb;
        private Button bk;
    }
}