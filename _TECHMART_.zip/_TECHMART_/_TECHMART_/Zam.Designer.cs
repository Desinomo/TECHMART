﻿namespace _TECHMART_
{
    partial class Zam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            dtz = new DataGridView();
            bz = new Button();
            be = new Button();
            bd = new Button();
            ba = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dtz).BeginInit();
            SuspendLayout();
            // 
            // dtz
            // 
            dtz.BackgroundColor = Color.Azure;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Azure;
            dataGridViewCellStyle1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dtz.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dtz.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Azure;
            dataGridViewCellStyle2.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dtz.DefaultCellStyle = dataGridViewCellStyle2;
            dtz.GridColor = SystemColors.ActiveCaptionText;
            dtz.ImeMode = ImeMode.NoControl;
            dtz.Location = new Point(12, 48);
            dtz.MultiSelect = false;
            dtz.Name = "dtz";
            dtz.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.Azure;
            dataGridViewCellStyle3.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dtz.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dtz.RowHeadersVisible = false;
            dtz.RowTemplate.DefaultCellStyle.BackColor = Color.Azure;
            dtz.RowTemplate.DefaultCellStyle.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtz.Size = new Size(657, 392);
            dtz.StandardTab = true;
            dtz.TabIndex = 3;
            dtz.UseWaitCursor = true;
            dtz.CellClick += dtz_CellClick_1;
            // 
            // bz
            // 
            bz.BackColor = Color.Azure;
            bz.Cursor = Cursors.Hand;
            bz.FlatStyle = FlatStyle.Popup;
            bz.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bz.Location = new Point(12, 446);
            bz.Name = "bz";
            bz.Size = new Size(657, 43);
            bz.TabIndex = 18;
            bz.Text = "Завершити замовлення";
            bz.UseVisualStyleBackColor = false;
            bz.Click += bz_Click;
            // 
            // be
            // 
            be.BackColor = Color.Azure;
            be.Cursor = Cursors.Hand;
            be.FlatStyle = FlatStyle.Popup;
            be.Font = new Font("Bookman Old Style", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            be.Location = new Point(12, 10);
            be.Name = "be";
            be.Size = new Size(29, 22);
            be.TabIndex = 19;
            be.Text = "<-";
            be.UseVisualStyleBackColor = false;
            be.Click += be_Click;
            // 
            // bd
            // 
            bd.BackColor = Color.Azure;
            bd.Cursor = Cursors.Hand;
            bd.FlatStyle = FlatStyle.Popup;
            bd.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bd.Location = new Point(297, 8);
            bd.Name = "bd";
            bd.Size = new Size(183, 32);
            bd.TabIndex = 20;
            bd.Text = "Видалити замовлення";
            bd.UseVisualStyleBackColor = false;
            bd.Click += bd_Click;
            // 
            // ba
            // 
            ba.BackColor = Color.Azure;
            ba.Cursor = Cursors.Hand;
            ba.FlatStyle = FlatStyle.Popup;
            ba.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ba.Location = new Point(486, 8);
            ba.Name = "ba";
            ba.Size = new Size(183, 32);
            ba.TabIndex = 21;
            ba.Text = "Зробити замовлення";
            ba.UseVisualStyleBackColor = false;
            ba.Click += ba_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Azure;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(108, 8);
            button1.Name = "button1";
            button1.Size = new Size(183, 32);
            button1.TabIndex = 22;
            button1.Text = "Пошук замовлення";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Zam
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(681, 501);
            Controls.Add(button1);
            Controls.Add(ba);
            Controls.Add(bd);
            Controls.Add(be);
            Controls.Add(bz);
            Controls.Add(dtz);
            Name = "Zam";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "_TECHMART_";
            ((System.ComponentModel.ISupportInitialize)dtz).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dtz;
        private Button bz;
        private Button be;
        private Button bd;
        private Button ba;
        private Button button1;
    }
}